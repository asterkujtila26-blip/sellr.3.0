import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'
import { taskUpdateSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

async function getOwnedTask(userId: string, id: string) {
  const task = await db.task.findUnique({ where: { id } })
  if (!task) throw new ApiError(404, 'Task not found.')
  const business = await db.business.findUnique({ where: { id: task.businessId } })
  if (!business || business.ownerId !== userId) throw new ApiError(404, 'Task not found.')
  return task
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params
    const task = await getOwnedTask(user.id, id)

    const body = await req.json()
    const input = taskUpdateSchema.parse(body)

    const updated = await db.task.update({
      where: { id: task.id },
      data: {
        ...(input.status ? { status: input.status } : {}),
        ...(input.priority ? { priority: input.priority } : {}),
        ...(input.title ? { title: input.title } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
        ...(input.dueDate !== undefined
          ? { dueDate: input.dueDate ? new Date(input.dueDate) : null }
          : {}),
        ...(input.status
          ? { completedAt: input.status === 'COMPLETED' ? new Date() : null }
          : {}),
      },
    })
    if (input.status === 'COMPLETED') {
      await logActivity(updated.businessId, 'TASK_COMPLETED', `Task completed: "${updated.title}"`)
    }
    return NextResponse.json({ task: updated })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params
    const task = await getOwnedTask(user.id, id)

    await db.task.delete({ where: { id: task.id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
