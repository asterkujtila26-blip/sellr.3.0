import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { metricSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

export async function GET() {
  try {
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const metrics = await db.businessMetric.findMany({
      where: { businessId: business.id },
      orderBy: [{ period: 'desc' }, { recordedAt: 'desc' }],
      take: 200,
    })
    return NextResponse.json({ metrics })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const body = await req.json()
    const input = metricSchema.parse(body)

    // One value per metric type per period — replace on re-entry.
    const metric = await db.businessMetric.upsert({
      where: {
        businessId_metricType_period: {
          businessId: business.id,
          metricType: input.metricType,
          period: input.period,
        },
      },
      update: { metricValue: input.metricValue, source: 'MANUAL', recordedAt: new Date() },
      create: {
        businessId: business.id,
        metricType: input.metricType,
        metricValue: input.metricValue,
        period: input.period,
        source: 'MANUAL',
      },
    })

    await logActivity(
      business.id,
      'METRIC_ADDED',
      `Recorded ${input.metricType.toLowerCase()} for ${input.period} (manual entry)`
    )
    return NextResponse.json({ metric })
  } catch (e) {
    return errorResponse(e)
  }
}
