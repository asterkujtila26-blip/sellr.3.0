import { NextRequest, NextResponse } from 'next/server'
import { destroySession } from '@/lib/auth'
import { assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { isSupabaseConfigured } from '@/lib/supabase/config'
import { createSupabaseServerClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    // Supabase: revoke the session server-side (refresh token invalidated at
    // the auth server) and clear its cookies.
    if (isSupabaseConfigured) {
      try {
        const supabase = await createSupabaseServerClient()
        await supabase.auth.signOut()
      } catch {
        // Session may already be gone — clearing cookies below still applies.
      }
    }
    // Local provider: clear the signed session cookie (also covers legacy
    // local cookies from before Supabase was enabled).
    await destroySession()
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
