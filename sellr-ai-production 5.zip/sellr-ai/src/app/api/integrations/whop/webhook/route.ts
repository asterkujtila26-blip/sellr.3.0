import { NextRequest, NextResponse } from 'next/server'
import { after } from 'next/server'
import { db } from '@/lib/db'
import { openSecret, standardWebhookSignature } from '@/lib/whop/crypto'
import { synchronizeBusiness } from '@/lib/whop/sync'

/**
 * Whop webhook receiver — PUBLIC endpoint, authenticated by Standard Webhooks
 * signatures (https://docs.whop.com/developer/guides/webhooks.md), never by a
 * user session.
 *
 * Contract:
 *  1. Read the RAW body (verification covers bytes, not parsed JSON).
 *  2. Verify HMAC-SHA256 over `{webhook-id}.{webhook-timestamp}.{body}` with
 *     each stored connection's ws_ secret; constant-time compare; reject when
 *     the timestamp drifts more than 5 minutes (replay protection).
 *  3. Persist the event id (globally unique per Whop) for idempotency —
 *     re-deliveries are acknowledged and skipped.
 *  4. Acknowledge 200 quickly (<5s) and run the resync AFTER the response
 *     via Next.js `after()`.
 */

const MAX_TIMESTAMP_DRIFT_SECONDS = 5 * 60

interface WhopWebhookEnvelope {
  id?: string
  type?: string
  api_version?: string
  account_id?: string
  company_id?: string
  data?: unknown
}

function extractSignatureCandidates(header: string | null): string[] {
  if (!header) return []
  // Format: "v1,<base64>" possibly repeated: "v1,sig1 v1,sig2"
  return header
    .split(' ')
    .map((part) => part.trim())
    .filter((part) => part.startsWith('v1,'))
    .map((part) => part.slice(3))
}

export async function POST(req: NextRequest) {
  const rawBody = await req.text()
  const webhookId = req.headers.get('webhook-id')
  const webhookTimestamp = req.headers.get('webhook-timestamp')
  const webhookSignature = req.headers.get('webhook-signature')

  const fail = (status: number, message: string) => {
    console.error('[SELLR Whop] webhook rejected', { status, message, webhookId })
    return NextResponse.json({ error: message }, { status })
  }

  if (!webhookId || !webhookTimestamp || !webhookSignature) {
    return fail(400, 'Missing webhook signature headers.')
  }

  const timestampSec = Number(webhookTimestamp)
  if (!Number.isFinite(timestampSec)) {
    return fail(400, 'Invalid webhook timestamp.')
  }
  const drift = Math.abs(Math.floor(Date.now() / 1000) - timestampSec)
  if (drift > MAX_TIMESTAMP_DRIFT_SECONDS) {
    return fail(401, 'Webhook timestamp outside the allowed window.')
  }

  // Load every connection with a registered webhook secret. Signatures must
  // verify against one of them; payloads are NEVER trusted before that.
  const connections = await db.whopConnection.findMany({
    where: { webhookId: { not: null }, webhookEncryptedSecret: { not: null } },
    select: {
      id: true,
      whopAccountId: true,
      webhookEncryptedSecret: true,
      webhookSecretIv: true,
      webhookSecretTag: true,
    },
  })

  let verifiedConnectionId: string | null = null
  for (const connection of connections) {
    try {
      const secret = openSecret({
        ciphertext: connection.webhookEncryptedSecret as string,
        iv: connection.webhookSecretIv as string,
        tag: connection.webhookSecretTag as string,
      })
      const expected = standardWebhookSignature(webhookId, webhookTimestamp, rawBody, secret)
      const candidates = extractSignatureCandidates(webhookSignature)
      if (candidates.some((candidate) => candidate === expected)) {
        verifiedConnectionId = connection.id
        break
      }
    } catch {
      // Undecryptable secret for this connection — try the next one.
    }
  }

  if (!verifiedConnectionId) {
    return fail(401, 'Signature verification failed.')
  }

  // Signature is valid — now the payload may be parsed.
  let envelope: WhopWebhookEnvelope
  try {
    envelope = JSON.parse(rawBody) as WhopWebhookEnvelope
  } catch {
    return fail(400, 'Webhook body is not valid JSON.')
  }

  const accountId = envelope.account_id ?? envelope.company_id ?? null
  const eventType = typeof envelope.type === 'string' ? envelope.type : 'unknown'

  // Idempotency: webhook-id is globally unique; re-deliveries are skipped.
  const existing = await db.whopWebhookEvent.findUnique({ where: { id: webhookId } })
  if (existing) {
    return NextResponse.json({ received: true, duplicate: true })
  }

  // Route to the connection that owns this Whop account (envelope truth).
  let connectionId: string | null = verifiedConnectionId
  if (accountId) {
    const owner = await db.whopConnection.findUnique({
      where: { whopAccountId: accountId },
      select: { id: true },
    })
    connectionId = owner?.id ?? null
  }

  await db.whopWebhookEvent.create({
    data: {
      id: webhookId,
      type: eventType,
      accountId,
      connectionId,
      status: connectionId ? 'RECEIVED' : 'SKIPPED_NO_CONNECTION',
    },
  })

  if (!connectionId) {
    return NextResponse.json({ received: true, routed: false })
  }

  // Resync AFTER the response — Whop requires a 2xx within 5 seconds and a
  // full sync may take longer on large accounts.
  after(async () => {
    try {
      await synchronizeBusiness(connectionId as string)
    } catch (e) {
      console.error('[SELLR Whop] background resync failed after webhook', e)
    }
  })

  return NextResponse.json({ received: true, routed: true })
}
