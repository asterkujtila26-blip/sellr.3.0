import { NextRequest, NextResponse } from 'next/server'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'
import { rateLimit } from '@/lib/rate-limit'
import { logActivity } from '@/lib/activity'
import { db } from '@/lib/db'
import { synchronizeBusiness } from '@/lib/whop/sync'
import { buildWhopStatus } from '@/lib/whop/status'

/** Trigger a fresh synchronization of the connected Whop business. */
export async function POST(req: NextRequest) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()

    const rl = rateLimit(`whop-sync:${user.id}`, 12, 10 * 60_000)
    if (!rl.ok) {
      throw new ApiError(429, `Please wait ${rl.retryAfterSec}s before syncing again.`)
    }

    const business = await requireBusiness(user.id)

    const connection = await db.whopConnection.findUnique({ where: { businessId: business.id } })
    if (!connection) {
      throw new ApiError(404, 'No Whop business is connected yet.')
    }

    const result = await synchronizeBusiness(connection.id)
    await logActivity(
      business.id,
      result.ok ? 'WHOP_SYNCED' : 'WHOP_SYNC_FAILED',
      result.ok
        ? `Whop sync completed: ${result.summary?.synced ?? 0} new metric${(result.summary?.synced ?? 0) === 1 ? '' : 's'} from Whop`
        : `Whop sync failed: ${result.error ?? 'unknown error'}`,
      null
    )

    const status = await buildWhopStatus(business.id)
    return NextResponse.json({ ...status, syncError: result.error })
  } catch (e) {
    return errorResponse(e)
  }
}
