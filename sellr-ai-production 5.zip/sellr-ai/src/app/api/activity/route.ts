import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { errorResponse } from '@/lib/api-helpers'
import { requireBusiness, requireUser } from '@/lib/auth'

export async function GET() {
  try {
    const user = await requireUser()
    const business = await requireBusiness(user.id)
    const activities = await db.activity.findMany({
      where: { businessId: business.id },
      orderBy: { createdAt: 'desc' },
      take: 15,
    })
    return NextResponse.json({ activities })
  } catch (e) {
    return errorResponse(e)
  }
}
