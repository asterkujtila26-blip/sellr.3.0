import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, assertSameOrigin, errorResponse } from '@/lib/api-helpers'
import { requireUser } from '@/lib/auth'
import { experimentUpdateSchema } from '@/lib/validation'
import { logActivity } from '@/lib/activity'

async function getOwnedExperiment(userId: string, id: string) {
  const experiment = await db.experiment.findUnique({ where: { id } })
  if (!experiment) throw new ApiError(404, 'Experiment not found.')
  const business = await db.business.findUnique({ where: { id: experiment.businessId } })
  if (!business || business.ownerId !== userId) throw new ApiError(404, 'Experiment not found.')
  return experiment
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params
    const experiment = await getOwnedExperiment(user.id, id)

    const body = await req.json()
    const input = experimentUpdateSchema.parse(body)

    const updated = await db.experiment.update({
      where: { id: experiment.id },
      data: {
        ...(input.status ? { status: input.status } : {}),
        ...(input.resultValue !== undefined ? { resultValue: input.resultValue } : {}),
        ...(input.status === 'COMPLETED' ? { completedAt: new Date() } : {}),
        ...(input.status && input.status !== 'COMPLETED' ? { completedAt: null } : {}),
      },
    })
    if (input.status === 'COMPLETED') {
      await logActivity(
        updated.businessId,
        'EXPERIMENT_COMPLETED',
        `Experiment completed: "${updated.title}"${updated.resultValue != null ? ` — result: ${updated.resultValue}` : ''}`
      )
    }
    return NextResponse.json({ experiment: updated })
  } catch (e) {
    return errorResponse(e)
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    assertSameOrigin(req)
    const user = await requireUser()
    const { id } = await params
    const experiment = await getOwnedExperiment(user.id, id)

    await db.experiment.delete({ where: { id: experiment.id } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return errorResponse(e)
  }
}
