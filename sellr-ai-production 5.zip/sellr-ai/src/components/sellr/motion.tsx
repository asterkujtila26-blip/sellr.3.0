'use client'

/**
 * SELLR.AI 2026 motion system.
 *
 * Design language:
 *  - Physics first: springs for anything interactive, long eased curves for
 *    entrances, blur-decay for a cinematic "developing photo" feel.
 *  - Every primitive respects `prefers-reduced-motion` (opacity-only fallbacks).
 *  - Decorative infinite loops (float/marquee/aurora) are pure CSS utilities in
 *    globals.css so they never re-render React.
 */

import {
  AnimatePresence,
  animate,
  motion,
  useInView,
  useReducedMotion,
  useSpring,
  type Transition,
  type Variants,
} from 'framer-motion'
import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'

export const EASE_OUT: [number, number, number, number] = [0.22, 1, 0.36, 1]

export const springSoft: Transition = { type: 'spring', stiffness: 120, damping: 18, mass: 0.9 }
export const springSnappy: Transition = { type: 'spring', stiffness: 420, damping: 32 }
export const springPop: Transition = { type: 'spring', stiffness: 300, damping: 20 }

/* ------------------------------------------------------------------ */
/* Entrances                                                           */
/* ------------------------------------------------------------------ */

/** Fade + rise + de-blur on mount. */
export function FadeIn({
  children,
  className,
  delay = 0,
  y = 14,
}: {
  children: React.ReactNode
  className?: string
  delay?: number
  y?: number
}) {
  const reduced = useReducedMotion()
  return (
    <motion.div
      className={className}
      initial={reduced ? { opacity: 0 } : { opacity: 0, y, filter: 'blur(6px)' }}
      animate={reduced ? { opacity: 1 } : { opacity: 1, y: 0, filter: 'blur(0px)' }}
      transition={{ duration: 0.55, ease: EASE_OUT, delay }}
    >
      {children}
    </motion.div>
  )
}

/** Reveal once when scrolled into view. */
export function Reveal({
  children,
  className,
  delay = 0,
  y = 22,
}: {
  children: React.ReactNode
  className?: string
  delay?: number
  y?: number
}) {
  const reduced = useReducedMotion()
  return (
    <motion.div
      className={className}
      initial={reduced ? { opacity: 0 } : { opacity: 0, y, filter: 'blur(8px)' }}
      whileInView={reduced ? { opacity: 1 } : { opacity: 1, y: 0, filter: 'blur(0px)' }}
      viewport={{ once: true, margin: '-10% 0px -6% 0px' }}
      transition={{ duration: 0.65, ease: EASE_OUT, delay }}
    >
      {children}
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/* Stagger orchestration                                               */
/* ------------------------------------------------------------------ */

export function Stagger({
  children,
  className,
  delay = 0,
  stagger = 0.07,
  inView = false,
  as = 'div',
}: {
  children: React.ReactNode
  className?: string
  delay?: number
  stagger?: number
  /** When true the cascade fires on scroll-into-view instead of mount. */
  inView?: boolean
  /** Semantic element for the orchestrator (keeps <section> semantics in views). */
  as?: 'div' | 'section'
}) {
  const reduced = useReducedMotion()
  const parent: Variants = {
    hidden: {},
    show: { transition: { staggerChildren: reduced ? 0 : stagger, delayChildren: delay } },
  }
  if (as === 'section') {
    if (inView) {
      return (
        <motion.section
          className={className}
          variants={parent}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-8% 0px' }}
        >
          {children}
        </motion.section>
      )
    }
    return (
      <motion.section className={className} variants={parent} initial="hidden" animate="show">
        {children}
      </motion.section>
    )
  }
  if (inView) {
    return (
      <motion.div
        className={className}
        variants={parent}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: '-8% 0px' }}
      >
        {children}
      </motion.div>
    )
  }
  return (
    <motion.div className={className} variants={parent} initial="hidden" animate="show">
      {children}
    </motion.div>
  )
}

export function StaggerItem({ children, className }: { children: React.ReactNode; className?: string }) {
  const reduced = useReducedMotion()
  const item: Variants = reduced
    ? { hidden: { opacity: 0 }, show: { opacity: 1, transition: { duration: 0.3 } } }
    : {
        hidden: { opacity: 0, y: 18, scale: 0.97 },
        show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.5, ease: EASE_OUT } },
      }
  return (
    <motion.div className={className} variants={item}>
      {children}
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/* Typography: word-by-word blur-in headlines                          */
/* ------------------------------------------------------------------ */

export interface BlurSegment {
  text: string
  className?: string
}

export function BlurWords({
  segments,
  className,
  delay = 0,
  stagger = 0.055,
}: {
  segments: BlurSegment[]
  className?: string
  delay?: number
  stagger?: number
}) {
  const reduced = useReducedMotion()
  const words = segments.flatMap((seg, si) =>
    seg.text
      .split(/\s+/)
      .filter(Boolean)
      .map((w) => ({ text: w, className: seg.className }))
  )

  return (
    <motion.span
      className={cn('inline-block', className)}
      initial="hidden"
      animate="show"
      variants={{
        hidden: {},
        show: {
          transition: { staggerChildren: reduced ? 0 : stagger, delayChildren: delay },
        },
      }}
    >
      {words.map((w, i) => (
        <motion.span
          key={`${w.text}-${i}`}
          className={cn('inline-block will-change-transform', w.className)}
          variants={{
            hidden: { opacity: 0, y: '0.5em', filter: 'blur(10px)' },
            show: {
              opacity: 1,
              y: '0em',
              filter: 'blur(0px)',
              transition: { duration: 0.6, ease: EASE_OUT },
            },
          }}
        >
          {w.text}
          {i < words.length - 1 ? '\u00A0' : ''}
        </motion.span>
      ))}
    </motion.span>
  )
}

/* ------------------------------------------------------------------ */
/* Interaction: magnetic pull, 3D tilt                                 */
/* ------------------------------------------------------------------ */

/** Cursor-magnetic wrapper — the element leans toward the pointer. */
export function Magnetic({
  children,
  className,
  strength = 0.28,
}: {
  children: React.ReactNode
  className?: string
  strength?: number
}) {
  const reduced = useReducedMotion()
  const x = useSpring(0, springSnappy)
  const y = useSpring(0, springSnappy)

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    if (reduced) return
    const rect = e.currentTarget.getBoundingClientRect()
    x.set((e.clientX - (rect.left + rect.width / 2)) * strength)
    y.set((e.clientY - (rect.top + rect.height / 2)) * strength)
  }
  function onLeave() {
    x.set(0)
    y.set(0)
  }

  return (
    <motion.div
      className={cn('inline-block', className)}
      style={{ x, y }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      whileTap={reduced ? undefined : { scale: 0.97 }}
    >
      {children}
    </motion.div>
  )
}

/** Subtle 3D tilt that follows the cursor, springs back on leave. */
export function TiltCard({
  children,
  className,
  max = 6,
}: {
  children: React.ReactNode
  className?: string
  max?: number
}) {
  const reduced = useReducedMotion()
  const rotateX = useSpring(0, springSoft)
  const rotateY = useSpring(0, springSoft)

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    if (reduced) return
    const rect = e.currentTarget.getBoundingClientRect()
    const px = (e.clientX - rect.left) / rect.width - 0.5
    const py = (e.clientY - rect.top) / rect.height - 0.5
    rotateY.set(px * max)
    rotateX.set(-py * max)
  }
  function onLeave() {
    rotateX.set(0)
    rotateY.set(0)
  }

  return (
    <motion.div
      className={className}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{ transformPerspective: 900, rotateX, rotateY }}
    >
      {children}
    </motion.div>
  )
}

/* ------------------------------------------------------------------ */
/* Data: animated counters                                             */
/* ------------------------------------------------------------------ */

export function CountUp({
  value,
  format = (v: number) => String(Math.round(v)),
  className,
  duration = 1.3,
  delay = 0,
}: {
  value: number
  format?: (v: number) => string
  className?: string
  duration?: number
  delay?: number
}) {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-5% 0px' })
  const [display, setDisplay] = useState(reduced ? value : 0)

  useEffect(() => {
    if (!inView) return
    if (reduced) {
      setDisplay(value)
      return
    }
    const controls = animate(0, value, {
      duration,
      delay,
      ease: EASE_OUT,
      onUpdate: (v) => setDisplay(v),
    })
    return () => controls.stop()
  }, [inView, value, duration, delay, reduced])

  return (
    <span ref={ref} className={className}>
      {format(display)}
    </span>
  )
}

/* ------------------------------------------------------------------ */
/* Layout: marquee + aurora ambience                                   */
/* ------------------------------------------------------------------ */

/** Infinite horizontal ticker (CSS-driven, duplicated content). */
export function Marquee({
  children,
  className,
  duration = 30,
}: {
  children: React.ReactNode
  className?: string
  duration?: number
}) {
  return (
    <div className={cn('marquee-mask overflow-hidden', className)}>
      <div className="animate-marquee flex w-max items-center" style={{ animationDuration: `${duration}s` }}>
        <div className="flex items-center">{children}</div>
        <div className="flex items-center" aria-hidden>
          {children}
        </div>
      </div>
    </div>
  )
}

/** Slow-drifting aurora orbs — ambient light behind hero sections. */
export function AuroraOrbs({ className }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={cn('pointer-events-none absolute inset-0 overflow-hidden', className)}
    >
      <div className="animate-aurora-a absolute -top-40 left-[15%] h-[26rem] w-[26rem] rounded-full bg-primary/20 blur-[130px]" />
      <div className="animate-aurora-b absolute top-24 right-[-6rem] h-[22rem] w-[22rem] rounded-full bg-[#ff8a3d]/12 blur-[120px]" />
      <div className="animate-aurora-c absolute bottom-[-8rem] left-[-4rem] h-[24rem] w-[24rem] rounded-full bg-[#FFD43B]/8 blur-[140px]" />
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Routing: page-level transitions                                     */
/* ------------------------------------------------------------------ */

/**
 * Cross-fade page shells. Wrap the switched content and give each page a key.
 * `animateOnMount=false` for nested shells (the parent already animates).
 */
export function PageTransition({
  pageKey,
  children,
  className,
  animateOnMount = true,
}: {
  pageKey: string
  children: React.ReactNode
  className?: string
  animateOnMount?: boolean
}) {
  const reduced = useReducedMotion()
  return (
    <AnimatePresence mode="wait" initial={animateOnMount}>
      <motion.div
        key={pageKey}
        initial={reduced ? { opacity: 0 } : { opacity: 0, y: 14, filter: 'blur(6px)' }}
        animate={reduced ? { opacity: 1 } : { opacity: 1, y: 0, filter: 'blur(0px)' }}
        exit={reduced ? { opacity: 0 } : { opacity: 0, y: -8, filter: 'blur(6px)', transition: { duration: 0.16, ease: 'easeIn' } }}
        transition={{ duration: 0.32, ease: EASE_OUT }}
        className={className}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  )
}
