'use client'

import { useEffect, useState } from 'react'
import { Building2, Database, Loader2, Save, ShieldCheck, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import { apiFetch } from '@/lib/client-api'
import { useSellr } from '@/store/sellr-store'
import type { Business } from '@/lib/types'
import { FadeIn, Stagger, StaggerItem } from './motion'
import { WhopCard } from './whop-card'

const BUSINESS_TYPES = [
  'Digital Products',
  'SaaS',
  'Community / Membership',
  'Coaching / Consulting',
  'E-commerce',
  'Agency / Services',
  'Content / Creator',
  'Other',
]

export function BusinessView() {
  const { user, business, setBusiness } = useSellr()

  const [name, setName] = useState('')
  const [businessType, setBusinessType] = useState('')
  const [platform, setPlatform] = useState('')
  const [website, setWebsite] = useState('')
  const [description, setDescription] = useState('')
  const [products, setProducts] = useState('')
  const [targetAudience, setTargetAudience] = useState('')
  const [currentMonthlyRevenue, setCurrentMonthlyRevenue] = useState('')
  const [monthlyRevenueGoal, setMonthlyRevenueGoal] = useState('')
  const [mainChallenge, setMainChallenge] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!business) return
    setName(business.name)
    setBusinessType(business.businessType)
    setPlatform(business.platform ?? '')
    setWebsite(business.website ?? '')
    setDescription(business.description ?? '')
    setProducts(business.products ?? '')
    setTargetAudience(business.targetAudience ?? '')
    setCurrentMonthlyRevenue(
      business.currentMonthlyRevenue != null ? String(business.currentMonthlyRevenue) : ''
    )
    setMonthlyRevenueGoal(
      business.monthlyRevenueGoal != null ? String(business.monthlyRevenueGoal) : ''
    )
    setMainChallenge(business.mainChallenge ?? '')
  }, [business])

  function parseNumber(v: string): number | null {
    const trimmed = v.trim().replace(/[$,\s]/g, '')
    if (!trimmed) return null
    const n = Number(trimmed)
    return Number.isFinite(n) && n >= 0 ? n : null
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    try {
      const data = await apiFetch<{ business: Business }>('/api/business', {
        method: 'PUT',
        body: JSON.stringify({
          name: name.trim(),
          businessType,
          platform: platform.trim() || null,
          website: website.trim() || null,
          description: description.trim() || null,
          products: products.trim() || null,
          targetAudience: targetAudience.trim() || null,
          currentMonthlyRevenue: parseNumber(currentMonthlyRevenue),
          monthlyRevenueGoal: parseNumber(monthlyRevenueGoal),
          mainChallenge: mainChallenge.trim() || null,
          onboarded: true,
        }),
      })
      setBusiness(data.business)
      toast.success('Business profile updated')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not save profile')
    } finally {
      setSaving(false)
    }
  }

  if (!business) return null

  return (
    <div className="space-y-4">
      <FadeIn>
        <h1 className="text-xl font-semibold tracking-tight md:text-2xl">Business Profile</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          This is the shared memory every agent uses. Keep it accurate.
        </p>
      </FadeIn>

      <Stagger className="grid gap-4 lg:grid-cols-3">
        <StaggerItem className="lg:col-span-2">
          <Card className="bg-card/80 h-full">
          <CardContent className="p-4 md:p-5">
            <form onSubmit={handleSave} className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-primary/30 bg-primary/10">
                  <Building2 className="h-4 w-4 text-primary" aria-hidden />
                </div>
                <div>
                  <p className="text-sm font-semibold">Business details</p>
                  <p className="text-xs text-muted-foreground">Context for all five agents</p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Business name</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} />
                </div>
                <div className="space-y-1.5">
                  <Label>Business type</Label>
                  <Select value={businessType} onValueChange={(v) => { if (v) setBusinessType(v) }}>
                    <SelectTrigger aria-label="Business type">
                      {/* Radix cannot resolve item text for programmatic values
                          until first open — render the label explicitly. */}
                      <SelectValue placeholder="Select a type">
                        {businessType || 'Select a type'}
                      </SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      {BUSINESS_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="platform">Main platform</Label>
                  <Input id="platform" value={platform} onChange={(e) => setPlatform(e.target.value)} placeholder="Whop, Gumroad…" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="website">Website</Label>
                  <Input id="website" value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://…" />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} maxLength={600} />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="products">Products / offers</Label>
                <Textarea id="products" value={products} onChange={(e) => setProducts(e.target.value)} rows={2} maxLength={500} />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="audience">Target audience</Label>
                <Input id="audience" value={targetAudience} onChange={(e) => setTargetAudience(e.target.value)} maxLength={300} />
              </div>

              <Separator />

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="currentRev">Current monthly revenue (USD)</Label>
                  <Input
                    id="currentRev"
                    inputMode="decimal"
                    value={currentMonthlyRevenue}
                    onChange={(e) => setCurrentMonthlyRevenue(e.target.value)}
                    placeholder="User-reported"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Labeled [USER-REPORTED] — agents never treat this as measured data.
                  </p>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="goalRev">Monthly revenue objective (USD)</Label>
                  <Input
                    id="goalRev"
                    inputMode="decimal"
                    value={monthlyRevenueGoal}
                    onChange={(e) => setMonthlyRevenueGoal(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="challenge">Main challenge right now</Label>
                <Textarea id="challenge" value={mainChallenge} onChange={(e) => setMainChallenge(e.target.value)} rows={2} maxLength={300} />
              </div>

              <div className="flex justify-end">
                <Button type="submit" disabled={saving || !businessType}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Save className="h-4 w-4" aria-hidden />}
                  Save profile
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
        </StaggerItem>

        <StaggerItem className="space-y-4">
          <Card className="bg-card/80">
            <CardContent className="p-4 md:p-5">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-secondary">
                  <User className="h-4 w-4 text-muted-foreground" aria-hidden />
                </div>
                <div>
                  <p className="text-sm font-semibold">Account</p>
                  <p className="text-xs text-muted-foreground">Your session details</p>
                </div>
              </div>
              <dl className="mt-4 space-y-2 text-xs">
                <div className="flex justify-between gap-2">
                  <dt className="text-muted-foreground">Name</dt>
                  <dd className="font-medium">{user?.fullName}</dd>
                </div>
                <div className="flex justify-between gap-2">
                  <dt className="text-muted-foreground">Email</dt>
                  <dd className="truncate font-medium">{user?.email}</dd>
                </div>
                <div className="flex justify-between gap-2">
                  <dt className="text-muted-foreground">Member since</dt>
                  <dd className="font-medium">
                    {new Date(business.createdAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </dd>
                </div>
              </dl>
            </CardContent>
          </Card>

          {/* Whop business integration — real connection, server-verified state */}
          <WhopCard />

          <Card className="bg-card/80">
            <CardContent className="p-4 md:p-5">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-secondary">
                  <Database className="h-4 w-4 text-muted-foreground" aria-hidden />
                </div>
                <div>
                  <p className="text-sm font-semibold">Data & integrity</p>
                  <p className="text-xs text-muted-foreground">How your data is treated</p>
                </div>
              </div>
              <ul className="mt-4 space-y-2.5 text-xs leading-relaxed text-muted-foreground">
                <li className="flex items-start gap-2">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" aria-hidden />
                  Your business data is isolated to your account and verified server-side on every request.
                </li>
                <li className="flex items-start gap-2">
                  <Database className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" aria-hidden />
                  Metrics come from manual entry and, when connected, from your real Whop business —
                  every metric row carries its source (MANUAL or WHOP). SELLR never simulates data.
                </li>
                <li className="flex items-start gap-2">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" aria-hidden />
                  Agents label every number as [MEASURED], [USER-REPORTED] or [ESTIMATE]. Fabricated
                  metrics are a design violation, not a bug.
                </li>
              </ul>
            </CardContent>
          </Card>
        </StaggerItem>
      </Stagger>
    </div>
  )
}
