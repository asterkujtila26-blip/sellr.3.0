'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { BarChart3, Info, Loader2, Plus, Target, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { apiFetch } from '@/lib/client-api'
import {
  type AnalyticsSummary,
  type Business,
  type BusinessMetric,
  type MetricSeries,
  type MetricType,
} from '@/lib/types'
import { cn } from '@/lib/utils'
import { EmptyState, SectionTitle, formatMetricValue, formatMoney, timeAgo } from './shared'
import { CountUp, FadeIn, Stagger, StaggerItem } from './motion'

// ---- Constants & helpers ----

const METRIC_TYPE_LABELS: Record<MetricType, string> = {
  REVENUE: 'Monthly revenue (USD)',
  SALES: 'Sales volume',
  CUSTOMERS: 'Active customers',
  CONVERSION: 'Conversion rate (%)',
  AOV: 'Avg order value (USD)',
  CHURN: 'Churn rate (%)',
}

const METRIC_TYPE_ORDER = Object.keys(METRIC_TYPE_LABELS) as MetricType[]

const METRIC_PLACEHOLDERS: Record<MetricType, string> = {
  REVENUE: 'e.g. 12500',
  SALES: 'e.g. 140',
  CUSTOMERS: 'e.g. 320',
  CONVERSION: 'e.g. 3.8',
  AOV: 'e.g. 47.5',
  CHURN: 'e.g. 2.1',
}

const PERIOD_REGEX = /^\d{4}-(0[1-9]|1[0-2])$/

const TOOLTIP_STYLE = {
  background: '#111318',
  border: '1px solid #292D35',
  borderRadius: 8,
  fontSize: 12,
} as const

const AXIS_TICK = { fill: '#9297A2', fontSize: 11 }

const compactNumberFormat = new Intl.NumberFormat('en-US', {
  notation: 'compact',
  maximumFractionDigits: 1,
})

function compactNumber(value: number): string {
  return compactNumberFormat.format(value)
}

function currentMonth(): string {
  const now = new Date()
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
}

function formatPeriod(period: string): string {
  const [y, m] = period.split('-').map(Number)
  if (!y || !m || m < 1 || m > 12) return period
  return new Date(y, m - 1, 1).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
}

function chartTickPeriod(period: string): string {
  const [y, m] = period.split('-').map(Number)
  if (!y || !m || m < 1 || m > 12) return period
  const d = new Date(y, m - 1, 1)
  return `${d.toLocaleDateString('en-US', { month: 'short' })} '${String(y).slice(2)}`
}

function parseMetricValue(v: string): number | null {
  const trimmed = v.trim().replace(/[$,\s]/g, '')
  if (!trimmed) return null
  const n = Number(trimmed)
  return Number.isFinite(n) && n >= 0 ? n : null
}

function healthScoreColor(score: number): string {
  if (score >= 70) return 'text-emerald-400'
  if (score >= 40) return 'text-amber-400'
  return 'text-red-400'
}

// ---- Small building blocks ----

function KpiCard({
  label,
  series,
  metricType,
}: {
  label: string
  series: MetricSeries
  metricType: string
}) {
  const latest = series.latest
  const delta = series.deltaPct
  return (
    <div className="rounded-xl border border-border bg-card p-4 md:p-5">
      <p className="text-xs text-muted-foreground">{label}</p>
      {latest ? (
        <>
          <p className="mt-1.5 text-xl font-semibold tracking-tight md:text-2xl">
            <CountUp value={latest.value} format={(v) => formatMetricValue(metricType, v)} />
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {delta != null ? (
              <span
                title="vs previous month"
                className={cn(
                  'inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[11px] font-medium',
                  delta >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                )}
              >
                {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(1)}%
              </span>
            ) : null}
            <span className="text-[11px] text-muted-foreground">{formatPeriod(latest.period)}</span>
          </div>
        </>
      ) : (
        <>
          <p className="mt-1.5 text-lg font-medium text-muted-foreground">No data</p>
          <p className="mt-1 text-[11px] text-muted-foreground">
            Record {label.toLowerCase()} below to see it here
          </p>
        </>
      )}
    </div>
  )
}

function AnalyticsSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-5">
            <Skeleton className="h-3 w-24" />
            <Skeleton className="mt-3 h-7 w-28" />
            <Skeleton className="mt-3 h-3 w-20" />
          </div>
        ))}
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {Array.from({ length: 2 }).map((_, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-5">
            <Skeleton className="h-3 w-32" />
            <Skeleton className="mt-4 h-32 w-full" />
          </div>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {Array.from({ length: 2 }).map((_, i) => (
          <div key={i} className="rounded-xl border border-border bg-card p-5">
            <Skeleton className="h-3 w-28" />
            <Skeleton className="mt-4 h-64 w-full" />
          </div>
        ))}
      </div>
    </div>
  )
}

// ---- Main view ----

export function AnalyticsView() {
  // Data
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [summary, setSummary] = useState<AnalyticsSummary | null>(null)
  const [metrics, setMetrics] = useState<BusinessMetric[]>([])

  // Metric entry form
  const [metricType, setMetricType] = useState<MetricType>('REVENUE')
  const [metricValue, setMetricValue] = useState('')
  const [period, setPeriod] = useState(currentMonth())
  const [formError, setFormError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  // Delete metric
  const [deleteMetricId, setDeleteMetricId] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)

  const fetchData = useCallback(async (silent = false): Promise<boolean> => {
    if (!silent) {
      setLoading(true)
      setLoadError(null)
    }
    try {
      const [summaryRes, metricsRes] = await Promise.all([
        apiFetch<{ summary: AnalyticsSummary; business: Business }>('/api/analytics/summary'),
        apiFetch<{ metrics: BusinessMetric[] }>('/api/metrics'),
      ])
      setSummary(summaryRes.summary)
      setMetrics(metricsRes.metrics)
      return true
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Could not load analytics.'
      if (silent) toast.error(message)
      else setLoadError(message)
      return false
    } finally {
      if (!silent) setLoading(false)
    }
  }, [])

  useEffect(() => {
    void fetchData()
  }, [fetchData])

  const visibleMetrics = useMemo(() => {
    return [...metrics]
      .sort((a, b) => {
        if (a.period !== b.period) return a.period < b.period ? 1 : -1
        return a.recordedAt < b.recordedAt ? 1 : -1
      })
      .slice(0, 20)
  }, [metrics])

  const salesCustomersData = useMemo(() => {
    if (!summary) return []
    const byPeriod = new Map<string, { period: string; sales?: number; customers?: number }>()
    for (const point of summary.sales.series) {
      byPeriod.set(point.period, { period: point.period, sales: point.value })
    }
    for (const point of summary.customers.series) {
      const row = byPeriod.get(point.period) ?? { period: point.period }
      row.customers = point.value
      byPeriod.set(point.period, row)
    }
    return [...byPeriod.values()].sort((a, b) => (a.period < b.period ? -1 : 1))
  }, [summary])

  const deleteTargetMetric = deleteMetricId
    ? metrics.find((m) => m.id === deleteMetricId) ?? null
    : null

  async function submitMetric() {
    setFormError(null)
    const value = parseMetricValue(metricValue)
    if (value == null) {
      setFormError('Enter a valid non-negative number.')
      return
    }
    if (!PERIOD_REGEX.test(period.trim())) {
      setFormError('Period must be in YYYY-MM format (e.g. 2025-06).')
      return
    }
    setSaving(true)
    try {
      await apiFetch<{ metric: BusinessMetric }>('/api/metrics', {
        method: 'POST',
        body: JSON.stringify({ metricType, metricValue: value, period: period.trim() }),
      })
      toast.success('Metric saved')
      setMetricValue('')
      await fetchData(true)
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Could not save the metric.')
    } finally {
      setSaving(false)
    }
  }

  async function confirmDeleteMetric() {
    if (!deleteMetricId) return
    setDeleting(true)
    try {
      await apiFetch<{ ok: boolean }>(`/api/metrics/${deleteMetricId}`, { method: 'DELETE' })
      toast.success('Metric deleted')
      setDeleteMetricId(null)
      await fetchData(true)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not delete the metric.')
    } finally {
      setDeleting(false)
    }
  }

  const hasAnyData = summary ? summary.hasData || summary.metricCount > 0 : false
  const isEmpty = summary ? summary.metricCount === 0 : false

  const metricFormCard = (
    <div className="rounded-xl border border-border bg-card p-5">
      <SectionTitle
        title="Add a metric"
        hint="Real numbers for one month — saving the same type + period updates it."
      />
      <div className="mt-4 space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="metricType">Metric</Label>
          <Select value={metricType} onValueChange={(v) => setMetricType(v as MetricType)}>
            <SelectTrigger id="metricType" className="w-full" aria-label="Metric type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {METRIC_TYPE_ORDER.map((t) => (
                <SelectItem key={t} value={t}>
                  {METRIC_TYPE_LABELS[t]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="metricValue">Value</Label>
            <Input
              id="metricValue"
              inputMode="decimal"
              value={metricValue}
              onChange={(e) => setMetricValue(e.target.value)}
              placeholder={METRIC_PLACEHOLDERS[metricType]}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="metricPeriod">Period</Label>
            <Input
              id="metricPeriod"
              type="month"
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
            />
          </div>
        </div>

        {formError ? (
          <p role="alert" className="text-xs text-destructive">
            {formError}
          </p>
        ) : null}

        <Button onClick={() => void submitMetric()} disabled={saving}>
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
          ) : (
            <Plus className="h-4 w-4" aria-hidden />
          )}
          Add metric
        </Button>

        <p className="flex items-start gap-2 rounded-lg border border-border bg-secondary/50 px-3 py-2.5 text-xs leading-relaxed text-muted-foreground">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
          <span>
            Data source: Manual entry. Direct platform integrations (e.g. Whop) are on the roadmap —
            SELLR never fabricates business metrics.
          </span>
        </p>
      </div>
    </div>
  )

  // ---- Render ----

  return (
    <div className="space-y-6">
      {/* Header */}
      <FadeIn>
        <h1 className="text-2xl font-semibold tracking-tight">Analytics</h1>
        <p className="mt-1 text-sm text-muted-foreground">Real numbers in, honest analysis out.</p>
      </FadeIn>

      {loadError && !loading ? (
        <div
          role="alert"
          className="flex flex-col gap-3 rounded-xl border border-destructive/30 bg-destructive/10 p-4 sm:flex-row sm:items-center sm:justify-between"
        >
          <p className="text-sm text-destructive">{loadError}</p>
          <Button size="sm" variant="outline" onClick={() => void fetchData()}>
            Try again
          </Button>
        </div>
      ) : null}

      {loading ? (
        <AnalyticsSkeleton />
      ) : !summary ? null : isEmpty ? (
        /* ------------------------------ Empty state ------------------------------ */
        <div className="space-y-6">
          <FadeIn>
            <EmptyState
              icon={BarChart3}
              title="No metrics yet"
              description="Add your first month of data below — revenue, sales, customers, conversion, AOV or churn. Your AI team analyzes what you actually record, never invented figures."
            />
          </FadeIn>
          <FadeIn delay={0.08}>{metricFormCard}</FadeIn>
        </div>
      ) : hasAnyData ? (
        /* ------------------------------ Full dashboard ------------------------------ */
        <div className="space-y-6">
          {/* KPI cards */}
          <section aria-label="Key metrics">
            <Stagger className="grid grid-cols-2 gap-4 lg:grid-cols-4">
              <StaggerItem><KpiCard label="Monthly Revenue" series={summary.revenue} metricType="REVENUE" /></StaggerItem>
              <StaggerItem><KpiCard label="Sales" series={summary.sales} metricType="SALES" /></StaggerItem>
              <StaggerItem><KpiCard label="Active Customers" series={summary.customers} metricType="CUSTOMERS" /></StaggerItem>
              <StaggerItem><KpiCard label="Conversion" series={summary.conversion} metricType="CONVERSION" /></StaggerItem>
            </Stagger>
          </section>

          {/* Goal + health */}
          <Stagger
            as="section"
            aria-label="Goal and health"
            className="grid gap-4 md:grid-cols-2"
          >
            <StaggerItem className="rounded-xl border border-border bg-card p-5">
              <SectionTitle title="Revenue goal" hint="Monthly revenue objective progress" />
              {summary.goal.target != null ? (
                <div className="mt-4 space-y-3">
                  <div className="flex flex-wrap items-end justify-between gap-2">
                    <p className="text-xl font-semibold tracking-tight">
                      {formatMoney(summary.goal.current ?? 0)}
                      <span className="ml-1.5 text-xs font-normal text-muted-foreground">
                        recorded
                      </span>
                    </p>
                    <p className="text-xs text-muted-foreground">
                      of {formatMoney(summary.goal.target)} target
                    </p>
                  </div>
                  <Progress
                    value={Math.max(0, Math.min(100, summary.goal.progressPct ?? 0))}
                    aria-label="Revenue goal progress"
                  />
                  <p className="text-xs text-muted-foreground">
                    {summary.goal.progressPct != null
                      ? `${Math.round(summary.goal.progressPct)}% of target achieved`
                      : 'Progress appears as you record revenue metrics.'}
                  </p>
                </div>
              ) : (
                <div className="mt-4 flex items-start gap-2.5 rounded-lg border border-dashed border-border bg-secondary/40 p-4">
                  <Target className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    Set a revenue objective in{' '}
                    <span className="font-medium text-foreground">Business Profile</span> to track
                    progress here.
                  </p>
                </div>
              )}
            </StaggerItem>

            <StaggerItem className="rounded-xl border border-border bg-card p-5">
              <SectionTitle title="Business health" hint="Composite estimate from recorded data" />
              {summary.healthScore ? (
                <div className="mt-4">
                  <div className="flex items-center gap-3">
                    <p
                      className={cn(
                        'text-3xl font-semibold tracking-tight',
                        healthScoreColor(summary.healthScore.score)
                      )}
                    >
                      <CountUp value={summary.healthScore.score} duration={1.1} />
                    </p>
                    <span className="rounded-full border border-border bg-secondary px-2.5 py-0.5 text-xs font-medium text-foreground">
                      {summary.healthScore.label}
                    </span>
                  </div>
                  <ul className="mt-3 space-y-1.5">
                    {summary.healthScore.factors.map((factor, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground"
                      >
                        <span
                          className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-primary"
                          aria-hidden
                        />
                        {factor}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-3 text-[11px] text-muted-foreground">
                    Heuristic estimate based on your recorded data.
                  </p>
                </div>
              ) : (
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  Add metrics to compute business health.
                </p>
              )}
            </StaggerItem>
          </Stagger>

          {/* Charts */}
          <Stagger as="section" aria-label="Trends" className="grid gap-4 lg:grid-cols-2">
            <StaggerItem className="rounded-xl border border-border bg-card p-5">
              <SectionTitle title="Revenue trend" hint="Monthly revenue across recorded periods" />
              {summary.revenue.series.length > 0 ? (
                <div className="mt-4">
                  <ResponsiveContainer width="100%" height={260}>
                    <AreaChart
                      data={summary.revenue.series}
                      margin={{ top: 4, right: 8, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid stroke="#292D35" strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="period"
                        tick={AXIS_TICK}
                        tickFormatter={(p: string) => chartTickPeriod(p)}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        tick={AXIS_TICK}
                        tickFormatter={(v) => formatMoney(Number(v), true)}
                        tickLine={false}
                        axisLine={false}
                        width={56}
                      />
                      <Tooltip
                        contentStyle={TOOLTIP_STYLE}
                        labelStyle={{ color: '#9297A2', fontSize: 11 }}
                        formatter={(value) => formatMoney(Number(value), false)}
                        cursor={{ stroke: '#292D35' }}
                      />
                      <Area
                        type="monotone"
                        dataKey="value"
                        name="Revenue"
                        stroke="#FF5A1F"
                        strokeWidth={2}
                        fill="rgba(139,124,255,0.12)"
                        activeDot={{ r: 4, fill: '#FF5A1F', stroke: '#111318' }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p className="mt-4 text-sm text-muted-foreground">
                  No revenue data yet — add monthly revenue metrics below.
                </p>
              )}
            </StaggerItem>

            <StaggerItem className="rounded-xl border border-border bg-card p-5">
              <SectionTitle title="Sales & customers">
                <div className="flex items-center gap-4">
                  <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="h-2 w-2 rounded-full bg-[#FBBF24]" aria-hidden />
                    Sales
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="h-2 w-2 rounded-full bg-[#22D3EE]" aria-hidden />
                    Customers
                  </span>
                </div>
              </SectionTitle>
              {salesCustomersData.length > 0 ? (
                <div className="mt-4">
                  <ResponsiveContainer width="100%" height={260}>
                    <LineChart
                      data={salesCustomersData}
                      margin={{ top: 4, right: 8, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid stroke="#292D35" strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="period"
                        tick={AXIS_TICK}
                        tickFormatter={(p: string) => chartTickPeriod(p)}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        tick={AXIS_TICK}
                        tickFormatter={(v) => compactNumber(Number(v))}
                        tickLine={false}
                        axisLine={false}
                        width={48}
                        allowDecimals={false}
                      />
                      <Tooltip
                        contentStyle={TOOLTIP_STYLE}
                        labelStyle={{ color: '#9297A2', fontSize: 11 }}
                        formatter={(value) => compactNumber(Number(value))}
                        cursor={{ stroke: '#292D35' }}
                      />
                      <Line
                        type="monotone"
                        dataKey="sales"
                        name="Sales"
                        stroke="#FBBF24"
                        strokeWidth={2}
                        dot={false}
                        activeDot={{ r: 4, fill: '#FBBF24', stroke: '#111318' }}
                        connectNulls
                      />
                      <Line
                        type="monotone"
                        dataKey="customers"
                        name="Customers"
                        stroke="#22D3EE"
                        strokeWidth={2}
                        dot={false}
                        activeDot={{ r: 4, fill: '#22D3EE', stroke: '#111318' }}
                        connectNulls
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p className="mt-4 text-sm text-muted-foreground">
                  No sales or customer data yet — record metrics below to see both lines.
                </p>
              )}
            </StaggerItem>
          </Stagger>

          {/* Metric entry form + recorded metrics table */}
          <Stagger
            as="section"
            aria-label="Manage metrics"
            className="grid grid-cols-1 items-start gap-4 lg:grid-cols-3 lg:gap-6"
          >
            <StaggerItem className="lg:col-span-1">{metricFormCard}</StaggerItem>

            <StaggerItem className="rounded-xl border border-border bg-card p-5 lg:col-span-2">
              <SectionTitle
                title="Recorded metrics"
                hint={`Latest ${Math.min(metrics.length, 20)} entries, newest first`}
              />
              {visibleMetrics.length > 0 ? (
                <div className="mt-4 max-h-[420px] overflow-y-auto scrollbar-slim">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-card">
                      <TableRow>
                        <TableHead>Metric</TableHead>
                        <TableHead>Value</TableHead>
                        <TableHead>Period</TableHead>
                        <TableHead>Source</TableHead>
                        <TableHead>Recorded</TableHead>
                        <TableHead className="w-10">
                          <span className="sr-only">Delete</span>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {visibleMetrics.map((m) => (
                        <TableRow key={m.id}>
                          <TableCell className="font-medium">
                            {METRIC_TYPE_LABELS[m.metricType]}
                          </TableCell>
                          <TableCell>
                            {formatMetricValue(m.metricType, m.metricValue, false)}
                          </TableCell>
                          <TableCell>{formatPeriod(m.period)}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className="border-border bg-muted text-[10px] font-medium text-muted-foreground"
                            >
                              {m.source}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {timeAgo(m.recordedAt)}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-destructive"
                              aria-label={`Delete ${METRIC_TYPE_LABELS[m.metricType]} for ${formatPeriod(m.period)}`}
                              onClick={() => setDeleteMetricId(m.id)}
                            >
                              <Trash2 className="h-3.5 w-3.5" aria-hidden />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <p className="mt-4 text-sm text-muted-foreground">
                  No metrics recorded yet — add your first one on the left.
                </p>
              )}
            </StaggerItem>
          </Stagger>
        </div>
      ) : (
        /* --------------------- Metrics exist but no series yet --------------------- */
        <div className="space-y-6">
          {metricFormCard}
        </div>
      )}

      {/* Delete metric confirmation */}
      <AlertDialog
        open={deleteMetricId !== null}
        onOpenChange={(open) => {
          if (!open) setDeleteMetricId(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete metric?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTargetMetric
                ? `${METRIC_TYPE_LABELS[deleteTargetMetric.metricType]} · ${formatPeriod(deleteTargetMetric.period)} will be removed. KPIs, charts and the health score update immediately.`
                : 'This recorded value will be removed permanently.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                void confirmDeleteMetric()
              }}
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
