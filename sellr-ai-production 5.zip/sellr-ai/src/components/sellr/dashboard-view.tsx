'use client'

import { useCallback, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  ArrowRight,
  BarChart3,
  Bot,
  Building2,
  CheckCircle2,
  CircleDollarSign,
  FlaskConical,
  HeartPulse,
  ListChecks,
  MessageSquarePlus,
  Sparkles,
  Target,
  TrendingUp,
  Users,
} from 'lucide-react'
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { apiFetch } from '@/lib/client-api'
import { useSellr } from '@/store/sellr-store'
import type { ActivityItem, AnalyticsSummary, Recommendation, Task } from '@/lib/types'
import {
  AgentChip,
  EmptyState,
  PriorityBadge,
  SectionTitle,
  StatusPill,
  formatMetricValue,
  timeAgo,
} from './shared'
import { CountUp, FadeIn, Stagger, StaggerItem, springSoft } from './motion'

interface DashboardData {
  summary: AnalyticsSummary
  recommendations: Recommendation[]
  tasks: Task[]
  activities: ActivityItem[]
}

const ACTIVITY_ICONS: Record<string, typeof Bot> = {
  ONBOARDED: Building2,
  METRIC_ADDED: BarChart3,
  AGENT_SESSION: Bot,
  RECOMMENDATION_CREATED: Sparkles,
  RECOMMENDATION_STATUS: ArrowRight,
  TASK_CREATED: ListChecks,
  TASK_COMPLETED: CheckCircle2,
  EXPERIMENT_CREATED: FlaskConical,
  EXPERIMENT_COMPLETED: FlaskConical,
}

function KpiCard({
  label,
  value,
  period,
  deltaPct,
  suffix,
}: {
  label: string
  value: number | null
  period: string | null
  deltaPct: number | null
  suffix?: string
}) {
  const periodLabel = period
    ? new Date(`${period}-01T00:00:00Z`).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    : null
  return (
    <Card className="bg-card/80">
      <CardContent className="p-4 md:p-5">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        {value != null ? (
          <>
            <p className="mt-1.5 text-2xl font-semibold tracking-tight">
              <CountUp value={value} format={(v) => formatMetricValue(suffix ?? 'REVENUE', v)} />
            </p>
            <div className="mt-1.5 flex items-center gap-2">
              {periodLabel ? <span className="text-[11px] text-muted-foreground">{periodLabel}</span> : null}
              {deltaPct != null ? (
                <span
                  className={`rounded-full border px-1.5 py-0.5 text-[10px] font-medium ${
                    deltaPct >= 0
                      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400'
                      : 'border-red-500/30 bg-red-500/10 text-red-400'
                  }`}
                >
                  {deltaPct >= 0 ? '▲' : '▼'} {Math.abs(deltaPct).toFixed(1)}%
                </span>
              ) : null}
            </div>
          </>
        ) : (
          <>
            <p className="mt-1.5 text-2xl font-semibold text-muted-foreground/50">—</p>
            <p className="mt-1.5 text-[11px] text-muted-foreground">No data yet — add metrics in Analytics</p>
          </>
        )}
      </CardContent>
    </Card>
  )
}

export function DashboardView() {
  const { user, business, setView } = useSellr()
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [completingTaskId, setCompletingTaskId] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const [summaryRes, recRes, taskRes, actRes] = await Promise.all([
        apiFetch<{ summary: AnalyticsSummary }>('/api/analytics/summary'),
        apiFetch<{ recommendations: Recommendation[] }>('/api/recommendations'),
        apiFetch<{ tasks: Task[] }>('/api/tasks'),
        apiFetch<{ activities: ActivityItem[] }>('/api/activity'),
      ])
      setData({
        summary: summaryRes.summary,
        recommendations: recRes.recommendations,
        tasks: taskRes.tasks,
        activities: actRes.activities,
      })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not load dashboard')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  async function completeTask(task: Task) {
    setCompletingTaskId(task.id)
    try {
      await apiFetch(`/api/tasks/${task.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'COMPLETED' }),
      })
      toast.success('Task completed')
      setData((prev) =>
        prev
          ? {
              ...prev,
              tasks: prev.tasks.map((t) =>
                t.id === task.id
                  ? { ...t, status: 'COMPLETED', completedAt: new Date().toISOString() }
                  : t
              ),
            }
          : prev
      )
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not update task')
    } finally {
      setCompletingTaskId(null)
    }
  }

  const firstName = user?.fullName.split(' ')[0] ?? 'there'
  const summary = data?.summary
  const openRecs = (data?.recommendations ?? []).filter((r) => r.status !== 'COMPLETED' && r.status !== 'CANCELLED')
  const openTasks = (data?.tasks ?? []).filter((t) => t.status === 'PLANNED' || t.status === 'IN_PROGRESS')
  const revenueSeries = (summary?.revenue.series ?? []).map((p) => ({
    period: new Date(`${p.period}-01T00:00:00Z`).toLocaleDateString('en-US', { month: 'short' }),
    value: p.value,
  }))

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-9 w-72" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-64 rounded-xl lg:col-span-2" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <FadeIn>
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
          <div>
            <h1 className="text-xl font-semibold tracking-tight md:text-2xl">
              Welcome back, {firstName}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {business?.name} · Your AI team is on standby.
            </p>
          </div>
          <Button onClick={() => setView('team')} className="shrink-0">
            <MessageSquarePlus className="h-4 w-4" aria-hidden />
            Ask SELLR CEO
          </Button>
        </div>
      </FadeIn>

      {/* KPI cards — honest empty states, never fabricated */}
      <Stagger className="grid grid-cols-2 gap-4 lg:grid-cols-4" aria-label="Key metrics">
        <StaggerItem>
          <KpiCard
            label="Monthly revenue"
            value={summary?.revenue.latest?.value ?? null}
            period={summary?.revenue.latest?.period ?? null}
            deltaPct={summary?.revenue.deltaPct ?? null}
          />
        </StaggerItem>
        <StaggerItem>
          <KpiCard
            label="Total sales"
            value={summary?.sales.latest?.value ?? null}
            period={summary?.sales.latest?.period ?? null}
            deltaPct={summary?.sales.deltaPct ?? null}
          />
        </StaggerItem>
        <StaggerItem>
          <KpiCard
            label="Active customers"
            value={summary?.customers.latest?.value ?? null}
            period={summary?.customers.latest?.period ?? null}
            deltaPct={summary?.customers.deltaPct ?? null}
          />
        </StaggerItem>
        <StaggerItem>
          <KpiCard
            label="Conversion rate"
            value={summary?.conversion.latest?.value ?? null}
            period={summary?.conversion.latest?.period ?? null}
            deltaPct={summary?.conversion.deltaPct ?? null}
            suffix="CONVERSION"
          />
        </StaggerItem>
      </Stagger>

      {/* Health + revenue trend + goal */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="bg-card/80 lg:col-span-2">
          <CardContent className="p-4 md:p-5">
            <SectionTitle
              title="Revenue trend"
              hint={
                revenueSeries.length >= 2
                  ? 'Recorded monthly revenue (manual entry)'
                  : 'Recorded revenue over time — add 2+ months in Analytics to see the trend'
              }
            />
            {revenueSeries.length >= 2 ? (
              <div className="mt-4 h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueSeries} margin={{ top: 6, right: 6, bottom: 0, left: 0 }}>
                    <defs>
                      <linearGradient id="dashRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#FF5A1F" stopOpacity={0.25} />
                        <stop offset="100%" stopColor="#FF5A1F" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="#292D35" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="period" tick={{ fill: '#9297A2', fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis
                      tick={{ fill: '#9297A2', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                      width={52}
                      tickFormatter={(v: number) =>
                        v >= 1000 ? `$${Math.round(v / 100) / 10}k` : `$${v}`
                      }
                    />
                    <Tooltip
                      contentStyle={{ background: '#111318', border: '1px solid #292D35', borderRadius: 8, fontSize: 12 }}
                      labelStyle={{ color: '#9297A2' }}
                      formatter={(value: number) => [`$${value.toLocaleString()}`, 'Revenue']}
                    />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="#FF5A1F"
                      strokeWidth={2}
                      fill="url(#dashRev)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="mt-4">
                <EmptyState
                  icon={TrendingUp}
                  title="Not enough revenue history yet"
                  description="Record your monthly revenue in Analytics. Two or more months unlock trend analysis for your AI team."
                >
                  <Button variant="secondary" size="sm" onClick={() => setView('analytics')}>
                    Add metrics
                  </Button>
                </EmptyState>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          {/* Business health */}
          <Card className="bg-card/80">
            <CardContent className="p-4 md:p-5">
              <SectionTitle title="Business health" />
              {summary?.healthScore ? (
                <>
                  <div className="mt-3 flex items-center gap-3">
                    <span
                      className={`text-3xl font-semibold tracking-tight ${
                        summary.healthScore.score >= 75
                          ? 'text-emerald-400'
                          : summary.healthScore.score >= 50
                            ? 'text-primary'
                            : summary.healthScore.score >= 25
                              ? 'text-amber-400'
                              : 'text-red-400'
                      }`}
                    >
                      <CountUp value={summary.healthScore.score} />
                    </span>
                    <span className="rounded-full border border-border bg-secondary px-2 py-0.5 text-xs text-muted-foreground">
                      {summary.healthScore.label}
                    </span>
                  </div>
                  <ul className="mt-3 space-y-1.5">
                    {summary.healthScore.factors.map((f, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-xs text-muted-foreground">
                        <HeartPulse className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground/60" aria-hidden />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2.5 text-[10px] text-muted-foreground/70">
                    Heuristic estimate based on your recorded data — not a financial judgment.
                  </p>
                </>
              ) : (
                <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
                  Health score appears once you record metrics or set a revenue objective. SELLR
                  never invents scores without data.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Revenue objective */}
          <Card className="bg-card/80">
            <CardContent className="p-4 md:p-5">
              <SectionTitle title="Revenue objective" />
              {summary?.goal.target != null && summary.goal.current != null ? (
                <>
                  <div className="mt-3 flex items-baseline justify-between">
                    <span className="text-lg font-semibold">
                      {formatMetricValue('REVENUE', summary.goal.current)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      of {formatMetricValue('REVENUE', summary.goal.target)}
                    </span>
                  </div>
                  <div className="mt-2 h-2 overflow-hidden rounded-full bg-secondary">
                    <motion.div
                      className="h-full rounded-full bg-primary"
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, summary.goal.progressPct ?? 0)}%` }}
                      transition={{ ...springSoft, delay: 0.25 }}
                    />
                  </div>
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    {Math.round(summary.goal.progressPct ?? 0)}% of objective reached
                  </p>
                </>
              ) : (
                <div className="mt-3 flex items-start gap-2 text-xs text-muted-foreground">
                  <Target className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                  <span>
                    {summary?.goal.target == null
                      ? 'Set a monthly revenue objective in Business Profile to track progress here.'
                      : 'Record revenue in Analytics to measure progress against your objective.'}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recommendations + tasks + activity */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="bg-card/80">
          <CardContent className="p-4 md:p-5">
            <SectionTitle
              title="AI recommendations"
              hint="Latest from your team"
            >
              <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground" onClick={() => setView('actions')}>
                View all <ArrowRight className="ml-1 h-3 w-3" aria-hidden />
              </Button>
            </SectionTitle>
            {openRecs.length > 0 ? (
              <Stagger className="mt-4 space-y-3" stagger={0.06}>
                {openRecs.slice(0, 3).map((rec) => (
                  <StaggerItem key={rec.id}>
                    <div className="rounded-lg border border-border bg-secondary/40 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <AgentChip agent={rec.agentType} />
                        <PriorityBadge priority={rec.priority} />
                      </div>
                      <p className="mt-2 text-sm font-medium leading-snug">{rec.title}</p>
                      <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                        {rec.description}
                      </p>
                    </div>
                  </StaggerItem>
                ))}
              </Stagger>
            ) : (
              <div className="mt-4">
                <EmptyState
                  icon={Sparkles}
                  title="No open recommendations"
                  description="Chat with your AI team — recommendations they make are saved here automatically."
                />
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card/80">
          <CardContent className="p-4 md:p-5">
            <SectionTitle title="Pending tasks" hint="What needs execution">
              <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground" onClick={() => setView('actions')}>
                Action Center <ArrowRight className="ml-1 h-3 w-3" aria-hidden />
              </Button>
            </SectionTitle>
            {openTasks.length > 0 ? (
              <Stagger className="mt-4 max-h-72 space-y-2 overflow-y-auto pr-1 scrollbar-slim" stagger={0.05}>
                {openTasks.slice(0, 6).map((task) => (
                  <StaggerItem key={task.id}>
                    <div
                      className="flex items-start gap-2.5 rounded-lg border border-border bg-secondary/40 p-3"
                    >
                      <button
                        type="button"
                        aria-label={`Complete task: ${task.title}`}
                        disabled={completingTaskId === task.id}
                        onClick={() => void completeTask(task)}
                        className="mt-0.5 rounded-full border border-border p-0.5 text-muted-foreground transition-colors hover:border-emerald-500/50 hover:text-emerald-400 disabled:opacity-50"
                      >
                        <CheckCircle2 className="h-4 w-4" aria-hidden />
                      </button>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium leading-snug">{task.title}</p>
                        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                          <StatusPill status={task.status} kind="task" />
                          <PriorityBadge priority={task.priority} />
                        </div>
                      </div>
                    </div>
                  </StaggerItem>
                ))}
              </Stagger>
            ) : (
              <div className="mt-4">
                <EmptyState
                  icon={ListChecks}
                  title="No pending tasks"
                  description="Convert recommendations into tasks in the Action Center to track execution."
                />
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card/80">
          <CardContent className="p-4 md:p-5">
            <SectionTitle title="Recent activity" hint="Your business timeline" />
            {(data?.activities.length ?? 0) > 0 ? (
              <div className="mt-4 max-h-80 space-y-3 overflow-y-auto pr-1 scrollbar-slim">
                {data?.activities.map((a) => {
                  const Icon = ACTIVITY_ICONS[a.type] ?? Bot
                  return (
                    <div key={a.id} className="flex items-start gap-2.5">
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-border bg-secondary">
                        <Icon className="h-3.5 w-3.5 text-muted-foreground" aria-hidden />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs leading-snug text-foreground/90">{a.description}</p>
                        <p className="mt-0.5 text-[10px] text-muted-foreground">{timeAgo(a.createdAt)}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <div className="mt-4">
                <EmptyState
                  icon={CircleDollarSign}
                  title="No activity yet"
                  description="Your timeline fills up as you add metrics, talk to agents and complete tasks."
                />
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
