'use client'

import {
  ArrowRight,
  Database,
  Eye,
  Gauge,
  ListChecks,
  LogIn,
  ShieldCheck,
  Target,
  Zap,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useSellr } from '@/store/sellr-store'
import { AGENT_META, type AgentType } from '@/lib/types'
import { AgentIcon, SellrLogo } from './shared'
import { AgentMascot, MascotRow } from './mascots'
import {
  AuroraOrbs,
  BlurWords,
  CountUp,
  FadeIn,
  Magnetic,
  Marquee,
  Reveal,
  Stagger,
  StaggerItem,
  TiltCard,
  springPop,
} from './motion'
import { motion } from 'framer-motion'

const AGENT_ORDER: AgentType[] = ['CEO', 'ANALYST', 'GROWTH', 'RETENTION', 'OPERATIONS']

const LOOP = [
  { icon: Eye, step: 'SEE', text: 'Understand your business with real data' },
  { icon: Target, step: 'DECIDE', text: 'Identify opportunities, prioritize actions' },
  { icon: Zap, step: 'EXECUTE', text: 'Turn recommendations into tasks' },
  { icon: Gauge, step: 'MEASURE', text: 'Track results and learn from outcomes' },
]

const FEATURES = [
  {
    icon: Database,
    title: 'Shared business memory',
    text: 'Every agent works from the same context — your profile, metrics, goals and history. No re-explaining.',
  },
  {
    icon: ListChecks,
    title: 'Built for execution',
    text: 'Recommendations land in an Action Center. Convert them into tasks, track status, measure impact.',
  },
  {
    icon: ShieldCheck,
    title: 'Honest by design',
    text: 'No invented metrics, no fake connections. Your data stays yours — labeled by source, isolated per account.',
  },
]

const STATS = [
  { value: 5, suffix: '', label: 'specialist agents on your team' },
  { value: 24, suffix: '/7', label: 'always on duty, never sleeping' },
  { value: 1, suffix: '', label: 'shared memory across the team' },
  { value: 0, suffix: '', label: 'invented numbers. ever.' },
]

const TICKER = ['SEE', 'DECIDE', 'EXECUTE', 'MEASURE']

function goAuth(mode: 'login' | 'register', setAuthMode: (m: 'login' | 'register') => void, setView: (v: 'auth') => void) {
  setAuthMode(mode)
  setView('auth')
}

export function LandingView() {
  const { setView, setAuthMode } = useSellr()

  return (
    <div className="flex min-h-screen flex-col sellr-backdrop">
      {/* Top nav */}
      <FadeIn>
        <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
          <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 md:px-6">
            <SellrLogo />
            <nav className="flex items-center gap-1.5" aria-label="Authentication">
              <Button
                variant="ghost"
                size="sm"
                className="h-9 rounded-full px-4 text-muted-foreground hover:text-foreground"
                onClick={() => goAuth('login', setAuthMode, setView)}
              >
                <LogIn className="h-4 w-4" aria-hidden />
                Sign in
              </Button>
              <Button
                size="sm"
                className="h-9 rounded-full px-5 font-semibold shadow-[0_4px_20px_rgba(255,78,0,0.35)] hover:shadow-[0_4px_28px_rgba(255,78,0,0.5)]"
                onClick={() => goAuth('register', setAuthMode, setView)}
              >
                Start free
              </Button>
            </nav>
          </div>
        </header>
      </FadeIn>

      <main className="flex-1">
        <div className="mx-auto w-full max-w-6xl px-4 md:px-6">
          {/* Hero — huge two-tone headline that develops word by word */}
          <section className="relative flex flex-col items-center pb-16 pt-14 text-center md:pb-24 md:pt-20">
            <AuroraOrbs />
            <motion.div
              initial={{ opacity: 0, scale: 0.7, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ ...springPop, delay: 0.05 }}
            >
              <Badge
                variant="outline"
                className="rounded-full border-primary/40 bg-primary/10 px-4 py-1 text-xs font-semibold uppercase tracking-[0.14em]"
              >
                <span className="text-shimmer">Your Personal AI Business Team</span>
              </Badge>
            </motion.div>

            <h1 className="mt-7 max-w-3xl text-5xl font-bold leading-[1.04] tracking-tight md:text-7xl">
              <BlurWords
                delay={0.18}
                segments={[
                  { text: 'We built your' },
                  { text: 'AI business team', className: 'text-primary' },
                ]}
              />
            </h1>
            <FadeIn delay={0.55} className="relative">
              <p className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
                Five coordinated agents — CEO, Analyst, Growth, Retention and
                Operations — working from one shared memory to answer a single
                question:{' '}
                <span className="font-medium text-foreground">
                  “What should I do next to make more money?”
                </span>
              </p>
            </FadeIn>

            <div className="relative">
              <MascotRow className="mt-10" />
            </div>

            <FadeIn delay={0.75} className="relative">
              <div className="mt-10 flex flex-col items-center gap-3 sm:flex-row">
                <Magnetic>
                  <Button
                    size="lg"
                    className="glow-pulse h-12 rounded-full px-8 text-base font-semibold"
                    onClick={() => goAuth('register', setAuthMode, setView)}
                  >
                    Meet your team
                    <ArrowRight className="h-4 w-4" aria-hidden />
                  </Button>
                </Magnetic>
                <Magnetic>
                  <Button
                    size="lg"
                    variant="secondary"
                    className="h-12 rounded-full px-8 text-base font-semibold"
                    onClick={() => goAuth('login', setAuthMode, setView)}
                  >
                    I already have an account
                  </Button>
                </Magnetic>
              </div>
            </FadeIn>
            <FadeIn delay={0.9} className="relative">
              <p className="mt-5 text-xs text-muted-foreground">
                Free to start · No credit card · Your data stays isolated to your account
              </p>
            </FadeIn>
          </section>
        </div>

        {/* Brand ticker */}
        <Reveal y={10}>
          <Marquee className="border-y border-border/60 bg-card/40 py-3">
            {Array.from({ length: 4 }).map((_, r) =>
              TICKER.map((t, i) => (
                <span
                  key={`${r}-${i}`}
                  className="mx-7 flex items-center gap-3 text-xs font-bold tracking-[0.3em] text-muted-foreground"
                >
                  {t} <span className="text-primary" aria-hidden>✦</span>
                </span>
              ))
            )}
          </Marquee>
        </Reveal>

        <div className="mx-auto w-full max-w-6xl px-4 md:px-6">
          {/* Product truths — counters animate on scroll */}
          <section aria-label="Product facts" className="pt-12 md:pt-16">
            <Stagger inView className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {STATS.map((s) => (
                <StaggerItem key={s.label}>
                  <div className="rounded-2xl border border-border bg-card/70 p-4 text-center transition-colors hover:border-primary/40 md:p-5">
                    <p className="text-3xl font-bold tracking-tight text-primary md:text-4xl">
                      <CountUp value={s.value} format={(v) => `${Math.round(v)}${s.suffix}`} />
                    </p>
                    <p className="mt-1.5 text-xs leading-snug text-muted-foreground">{s.label}</p>
                  </div>
                </StaggerItem>
              ))}
            </Stagger>
          </section>

          {/* Operating loop */}
          <section aria-label="How SELLR works" className="pb-16 pt-14 md:pt-16">
            <Reveal>
              <div className="flex items-center gap-3">
                <h2 className="text-sm font-bold tracking-[0.14em] text-muted-foreground">
                  THE OPERATING LOOP.
                </h2>
              </div>
            </Reveal>
            <Stagger inView className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
              {LOOP.map((item) => (
                <StaggerItem key={item.step}>
                  <TiltCard className="h-full">
                    <div className="h-full rounded-2xl border border-border bg-card/70 p-4 transition-colors hover:border-primary/40 md:p-5">
                      <div className="flex items-center gap-2">
                        <item.icon className="h-4 w-4 text-primary" aria-hidden />
                        <span className="text-xs font-bold tracking-[0.14em] text-primary">
                          {item.step}
                        </span>
                      </div>
                      <p className="mt-2.5 text-sm leading-snug text-muted-foreground">{item.text}</p>
                    </div>
                  </TiltCard>
                </StaggerItem>
              ))}
            </Stagger>
          </section>

          {/* Agents — now with faces */}
          <section aria-label="The team" className="pb-16">
            <Reveal>
              <div className="flex items-center gap-3">
                <h2 className="text-sm font-bold tracking-[0.14em] text-muted-foreground">
                  FIVE SPECIALISTS. ONE COORDINATED TEAM.
                </h2>
              </div>
            </Reveal>
            <Stagger inView className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {AGENT_ORDER.map((agent) => {
                const meta = AGENT_META[agent]
                return (
                  <StaggerItem key={agent} className="h-full">
                    <TiltCard className="h-full" max={7}>
                      <div className="group h-full rounded-2xl border border-border bg-card/70 p-5 transition-all hover:-translate-y-0.5 hover:border-primary/40">
                        <div className="flex items-center gap-3">
                          <AgentMascot
                            agent={agent}
                            className="h-11 w-11 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6"
                          />
                          <div>
                            <p className="text-sm font-bold">{meta.name}</p>
                            <p className="text-xs text-muted-foreground">{meta.role}</p>
                          </div>
                          <div className="ml-auto flex h-7 w-7 items-center justify-center rounded-lg border border-border bg-secondary/60">
                            <AgentIcon agent={agent} className="h-3.5 w-3.5" />
                          </div>
                        </div>
                        <p className="mt-3.5 text-sm leading-relaxed text-muted-foreground">
                          {meta.blurb}
                        </p>
                      </div>
                    </TiltCard>
                  </StaggerItem>
                )
              })}
            </Stagger>
          </section>

          {/* Features */}
          <section aria-label="Why SELLR" className="pb-20">
            <Stagger inView className="grid gap-3 md:grid-cols-3">
              {FEATURES.map((f) => (
                <StaggerItem key={f.title} className="h-full">
                  <TiltCard className="h-full">
                    <div className="h-full rounded-2xl border border-border bg-card/70 p-5 transition-colors hover:border-primary/40">
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10">
                        <f.icon className="h-4.5 w-4.5 text-primary" aria-hidden />
                      </div>
                      <h3 className="mt-3.5 text-sm font-bold">{f.title}</h3>
                      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{f.text}</p>
                    </div>
                  </TiltCard>
                </StaggerItem>
              ))}
            </Stagger>
          </section>
        </div>
      </main>

      {/* Sticky footer */}
      <footer className="mt-auto border-t border-border/60 bg-background">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-muted-foreground sm:flex-row md:px-6">
          <p>© {new Date().getFullYear()} SELLR.AI — Your Personal AI Business Team</p>
          <p className="tracking-[0.14em]">SEE → DECIDE → EXECUTE → MEASURE</p>
        </div>
      </footer>
    </div>
  )
}
