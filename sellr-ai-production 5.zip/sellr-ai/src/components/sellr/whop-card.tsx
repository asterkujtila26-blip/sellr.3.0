'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  ExternalLink,
  KeyRound,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Unlink,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'
import { apiFetch } from '@/lib/client-api'
import { cn } from '@/lib/utils'
import type { WhopIntegrationStatus } from '@/lib/types'
import { timeAgo } from './shared'

/**
 * Whop business integration card (Business Profile → right column).
 *
 * The connection state shown here is ALWAYS the server's truth — fetched from
 * GET /api/integrations/whop/status after mount and after every mutation.
 * "Connected" is never displayed before server-side verification succeeded,
 * and the API key typed by the user is sent once and never stored client-side.
 */

type EnvironmentChoice = 'sandbox' | 'production'

const STATUS_BADGES: Record<string, { label: string; className: string }> = {
  CONNECTED: { label: 'Connected', className: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' },
  SYNCING: { label: 'Synchronizing', className: 'bg-primary/10 text-primary border-primary/30' },
  SYNC_FAILED: { label: 'Sync failed', className: 'bg-red-500/10 text-red-400 border-red-500/30' },
  REAUTH_REQUIRED: { label: 'Reauthorization required', className: 'bg-amber-500/10 text-amber-400 border-amber-500/30' },
  DISCONNECTED: { label: 'Disconnected', className: 'bg-secondary text-muted-foreground border-border' },
}

export function WhopCard() {
  const [status, setStatus] = useState<WhopIntegrationStatus | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [apiKey, setApiKey] = useState('')
  const [environment, setEnvironment] = useState<EnvironmentChoice>('sandbox')
  const [connecting, setConnecting] = useState(false)
  const [syncingNow, setSyncingNow] = useState(false)
  const [confirmDisconnect, setConfirmDisconnect] = useState(false)
  const confirmTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const refresh = useCallback(async () => {
    try {
      const data = await apiFetch<WhopIntegrationStatus>('/api/integrations/whop/status')
      setStatus(data)
      setLoadError(null)
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : 'Could not load integration status')
    }
  }, [])

  useEffect(() => {
    void refresh()
  }, [refresh])

  // Follow server-driven sync states (including webhook-triggered syncs).
  useEffect(() => {
    const statusValue = status?.connection?.status
    if (statusValue !== 'SYNCING') return
    const timer = setInterval(() => void refresh(), 3000)
    return () => clearInterval(timer)
  }, [status?.connection?.status, refresh])

  useEffect(() => {
    return () => {
      if (confirmTimer.current) clearTimeout(confirmTimer.current)
    }
  }, [])

  async function handleConnect(e: React.FormEvent) {
    e.preventDefault()
    if (!apiKey.trim() || connecting) return
    setConnecting(true)
    try {
      const data = await apiFetch<WhopIntegrationStatus>('/api/integrations/whop/connect', {
        method: 'POST',
        body: JSON.stringify({ apiKey: apiKey.trim(), environment }),
      })
      setStatus(data)
      setApiKey('')
      const conn = data.connection
      if (conn?.status === 'CONNECTED') {
        toast.success(`Whop connected${conn.whopAccountName ? `: ${conn.whopAccountName}` : ''}`)
      } else if (conn?.status === 'SYNC_FAILED') {
        toast.warning('Whop account verified, but the first sync failed. See the card for details.')
      } else {
        toast.error('Whop connection did not complete. See the card for details.')
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not connect Whop')
    } finally {
      setConnecting(false)
    }
  }

  async function handleSync() {
    if (syncingNow) return
    setSyncingNow(true)
    try {
      const data = await apiFetch<WhopIntegrationStatus & { syncError?: string | null }>(
        '/api/integrations/whop/sync',
        { method: 'POST' }
      )
      setStatus(data)
      if (data.connection?.status === 'CONNECTED') {
        toast.success('Whop data synchronized')
      } else {
        toast.error(data.syncError ?? 'Synchronization failed')
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Synchronization failed')
      void refresh()
    } finally {
      setSyncingNow(false)
    }
  }

  async function handleDisconnect() {
    if (!confirmDisconnect) {
      setConfirmDisconnect(true)
      if (confirmTimer.current) clearTimeout(confirmTimer.current)
      confirmTimer.current = setTimeout(() => setConfirmDisconnect(false), 4000)
      return
    }
    setConfirmDisconnect(false)
    try {
      await apiFetch('/api/integrations/whop/disconnect', { method: 'POST' })
      toast.success('Whop disconnected — stored credentials deleted')
      await refresh()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not disconnect')
    }
  }

  const connection = status?.connection
  const badge = connection ? STATUS_BADGES[connection.status] : null
  const isBusy = connecting || syncingNow || connection?.status === 'SYNCING'
  const isUsable = connection?.status === 'CONNECTED' || connection?.status === 'SYNCING'
  const needsReauth = connection?.status === 'REAUTH_REQUIRED'
  const syncFailed = connection?.status === 'SYNC_FAILED'

  return (
    <div className="rounded-xl border border-border bg-card/80">
      <div className="p-4 md:p-5">
        {/* Header */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#1B6DFF]/15">
            <span className="text-sm font-black leading-none text-[#6C9EFF]">W</span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold">Whop</p>
            <p className="text-xs text-muted-foreground">Connect your Whop business — real data, no simulation</p>
          </div>
          {badge ? (
            <span className={cn('shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-medium', badge.className)}>
              {badge.label}
            </span>
          ) : null}
        </div>

        {/* Load error */}
        {loadError ? (
          <p role="alert" className="mt-3 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
            {loadError}
          </p>
        ) : null}

        {/* Server-side encryption not configured */}
        {status && !status.configured && !connection ? (
          <div role="alert" className="mt-3 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs leading-relaxed text-amber-400">
            <p className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              <span>
                Credential storage is not configured on this server. Set <code className="rounded bg-black/30 px-1">WHOP_ENCRYPTION_KEY</code> to a 64-character hex string and restart the app. Whop will refuse to store keys unencrypted.
              </span>
            </p>
          </div>
        ) : null}

        {/* Not connected → connect form */}
        {status && !connection ? (
          <form onSubmit={handleConnect} className="mt-4 space-y-3">
            <div className="space-y-1.5">
              <label htmlFor="whop-api-key" className="text-xs font-medium">
                Whop Account API key
              </label>
              <Input
                id="whop-api-key"
                type="password"
                inputMode="text"
                autoComplete="off"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Paste the key from Whop → Settings → Developer"
                disabled={connecting}
                className="h-10"
                required
                minLength={10}
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium">Whop environment</label>
              <Select
                value={environment}
                onValueChange={(v) => {
                  if (v === 'sandbox' || v === 'production') setEnvironment(v)
                }}
              >
                <SelectTrigger className="h-10" aria-label="Whop environment">
                  <SelectValue>
                    {environment === 'sandbox' ? 'Sandbox (no real money)' : 'Production (real data)'}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sandbox">Sandbox — test data from sandbox.whop.com</SelectItem>
                  <SelectItem value="production">Production — your live Whop business</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="w-full" disabled={connecting || !apiKey.trim()}>
              {connecting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <KeyRound className="h-4 w-4" aria-hidden />}
              {connecting ? 'Verifying with Whop…' : 'Connect Whop'}
            </Button>
            <p className="text-[11px] leading-relaxed text-muted-foreground">
              Your key is verified against the Whop API, then encrypted (AES-256-GCM) and stored
              server-side. It is never exposed to the browser again.{' '}
              <a
                href="https://whop.com/dashboard/developer"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-0.5 text-primary hover:underline"
              >
                Create a key <ExternalLink className="h-2.5 w-2.5" aria-hidden />
              </a>
            </p>
          </form>
        ) : null}

        {/* Connected states */}
        {connection ? (
          <div className="mt-4 space-y-3">
            <dl className="space-y-1.5 text-xs">
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Whop account</dt>
                <dd className="min-w-0 truncate font-medium">
                  {connection.whopAccountName ?? connection.whopAccountId}
                </dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Environment</dt>
                <dd className="font-medium capitalize">{connection.environment}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Key</dt>
                <dd className="font-medium font-mono">····{connection.keyHint ?? '····'}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Webhook</dt>
                <dd className="font-medium">
                  {connection.webhookRegistered ? 'Registered' : 'Not registered'}
                </dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Last sync</dt>
                <dd className="font-medium">
                  {connection.lastSyncAt ? (
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3 w-3 text-muted-foreground" aria-hidden />
                      {timeAgo(connection.lastSyncAt)}
                    </span>
                  ) : (
                    'Never'
                  )}
                </dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-muted-foreground">Whop metrics</dt>
                <dd className="font-medium">{connection.metricCount}</dd>
              </div>
            </dl>

            {/* Sync summary */}
            {connection.summary ? (
              <div className="rounded-lg border border-border bg-secondary/40 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                <p>
                  {connection.summary.synced} metric{connection.summary.synced === 1 ? '' : 's'} synced ·{' '}
                  {connection.summary.paymentsConsidered} paid payments ·{' '}
                  {connection.summary.skippedExisting} period
                  {connection.summary.skippedExisting === 1 ? '' : 's'} left untouched (already had data)
                  {connection.summary.currency ? ` · ${connection.summary.currency.toUpperCase()}` : ''}
                </p>
                {connection.summary.warnings.length > 0 ? (
                  <ul className="mt-1.5 space-y-1">
                    {connection.summary.warnings.map((w) => (
                      <li key={w} className="flex items-start gap-1.5">
                        <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-amber-400" aria-hidden />
                        <span>{w}</span>
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
            ) : null}

            {/* Sync error */}
            {connection.lastSyncError ? (
              <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs leading-relaxed text-destructive">
                {connection.lastSyncError}
              </p>
            ) : null}

            {/* Reauthorization required */}
            {needsReauth ? (
              <p className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs leading-relaxed text-amber-400">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                <span>Whop no longer accepts the stored key (revoked or expired). Reconnect with a fresh key to resume syncing.</span>
              </p>
            ) : null}

            {/* Sync failed hint */}
            {syncFailed && connection.lastSyncError ? (
              <p className="flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs leading-relaxed text-red-400">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
                <span>The last synchronization failed. You can retry below — previously synced data is safe.</span>
              </p>
            ) : null}

            {/* Actions */}
            <div className="flex flex-wrap items-center gap-2">
              <Button
                size="sm"
                variant="secondary"
                onClick={() => void handleSync()}
                disabled={isBusy || needsReauth}
              >
                {syncingNow || connection.status === 'SYNCING' ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                ) : (
                  <RefreshCw className="h-3.5 w-3.5" aria-hidden />
                )}
                {connection.status === 'SYNCING' ? 'Synchronizing…' : 'Sync now'}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => void handleDisconnect()}
                disabled={connecting || syncingNow}
                className={cn(
                  'text-muted-foreground hover:text-destructive',
                  confirmDisconnect && 'border border-destructive/40 bg-destructive/10 text-destructive hover:text-destructive'
                )}
              >
                <Unlink className="h-3.5 w-3.5" aria-hidden />
                {confirmDisconnect ? 'Confirm disconnect' : 'Disconnect'}
              </Button>
              {isUsable && !syncFailed ? (
                <span className="ml-auto inline-flex items-center gap-1 text-[11px] text-emerald-400">
                  <CheckCircle2 className="h-3 w-3" aria-hidden />
                  Verified by server
                </span>
              ) : null}
            </div>

            {/* Metric provenance note */}
            <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-muted-foreground">
              <ShieldCheck className="mt-0.5 h-3 w-3 shrink-0 text-emerald-400" aria-hidden />
              <span>
                Every synced metric is labeled source&nbsp;WHOP. Manually entered months are never
                overwritten — Whop fills only empty periods, and currencies are never mixed.
              </span>
            </p>
          </div>
        ) : null}
      </div>
    </div>
  )
}
