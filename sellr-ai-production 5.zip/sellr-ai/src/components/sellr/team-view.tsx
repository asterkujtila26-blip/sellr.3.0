'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import {
  ArrowDown,
  ArrowUp,
  Bot,
  Crown,
  Loader2,
  MessageSquarePlus,
  Sparkles,
  Trash2,
  Workflow,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import { apiFetch } from '@/lib/client-api'
import { cn } from '@/lib/utils'
import {
  AGENT_META,
  type AgentType,
  type ChatMessage,
  type Conversation,
  type MessageMeta,
  type Recommendation,
} from '@/lib/types'
import { AgentChip, AgentIcon, timeAgo } from './shared'
import { EASE_OUT, FadeIn, Stagger, StaggerItem, springSnappy } from './motion'
import { SellrThinking } from './sellr-thinking'

const AGENT_ORDER: AgentType[] = ['CEO', 'ANALYST', 'GROWTH', 'RETENTION', 'OPERATIONS']

const SUGGESTIONS: Record<AgentType, string[]> = {
  CEO: [
    'What should I do next to make more money?',
    'Give me a 7-day plan to grow my business',
    'What am I missing in my business right now?',
  ],
  ANALYST: [
    'Analyze my revenue and sales performance',
    'Where are my biggest revenue leaks?',
    'Give me a business health report',
  ],
  GROWTH: [
    'Give me 3 customer acquisition experiments for this month',
    'How can I improve my conversion?',
    'Suggest a pricing experiment',
  ],
  RETENTION: [
    'How can I reduce churn?',
    'Design a win-back campaign for inactive customers',
    'How do I improve the member experience?',
  ],
  OPERATIONS: [
    'Turn my open recommendations into a weekly plan',
    'What should I focus on this week?',
    'Help me organize my business workflows',
  ],
}

/** Distance (px) from the bottom within which auto-follow stays enabled. */
const NEAR_BOTTOM_THRESHOLD = 120
/** Composer auto-grow cap (px) — matches max-h-40 on the textarea. */
const COMPOSER_MAX_HEIGHT = 160

function parseMeta(raw: string | null): MessageMeta | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' ? (parsed as MessageMeta) : null
  } catch {
    return null
  }
}

function PipelineDisplay({ meta }: { meta: MessageMeta }) {
  const [open, setOpen] = useState(false)
  if (!meta.pipeline || meta.pipeline.length === 0) return null
  return (
    <div className="mt-3 border-t border-border/60 pt-2.5">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
        aria-expanded={open}
      >
        <Workflow className="h-3 w-3" aria-hidden />
        How this answer was built ({meta.pipeline.length} step{meta.pipeline.length > 1 ? 's' : ''})
      </button>
      {open ? (
        <ol className="mt-2 space-y-1.5">
          {meta.pipeline.map((step, i) => (
            <li key={i} className="flex items-start gap-2 text-[11px] text-muted-foreground">
              <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-border bg-secondary text-[9px] font-medium">
                {i + 1}
              </span>
              <span className={cn('font-medium', AGENT_META[step.agent]?.color)}>{step.agent}</span>
              <span className="min-w-0 flex-1">{step.action}</span>
            </li>
          ))}
        </ol>
      ) : null}
    </div>
  )
}

export function TeamView() {
  const [conversations, setConversations] = useState<Conversation[] | null>(null)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [agent, setAgent] = useState<AgentType>('CEO')
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [savedRecs, setSavedRecs] = useState<Record<string, Recommendation[]>>({})
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [loadingMessages, setLoadingMessages] = useState(false)
  const [showJumpToLatest, setShowJumpToLatest] = useState(false)
  const bottomRef = useRef<HTMLDivElement | null>(null)
  const scrollRef = useRef<HTMLDivElement | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement | null>(null)
  // Scroll-following state (refs: no re-renders on scroll events).
  const nearBottomRef = useRef(true)
  const prevScrollHeightRef = useRef(0)
  const justSentRef = useRef(false)

  const loadConversations = useCallback(async () => {
    try {
      const data = await apiFetch<{ conversations: Conversation[] }>('/api/conversations')
      setConversations(data.conversations)
      return data.conversations
    } catch {
      setConversations([])
      return []
    }
  }, [])

  useEffect(() => {
    void loadConversations()
  }, [loadConversations])

  // Follow new content only when the user is already near the bottom (or just
  // sent a message). Instant positioning — never repeated smooth animations.
  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const heightChanged = el.scrollHeight !== prevScrollHeightRef.current
    prevScrollHeightRef.current = el.scrollHeight
    if (!heightChanged) return
    if (nearBottomRef.current || justSentRef.current) {
      el.scrollTop = el.scrollHeight
      justSentRef.current = false
      nearBottomRef.current = true
      setShowJumpToLatest(false)
    }
  }, [messages, sending, loadingMessages])

  // Auto-grow the composer whenever its value changes (including suggestion fills).
  useEffect(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, COMPOSER_MAX_HEIGHT)}px`
  }, [input])

  function handleScroll() {
    const el = scrollRef.current
    if (!el) return
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight
    const near = distance < NEAR_BOTTOM_THRESHOLD
    nearBottomRef.current = near
    setShowJumpToLatest((prev) => {
      const next = !near && messages.length > 0
      return prev === next ? prev : next
    })
  }

  function scrollToLatest() {
    const el = scrollRef.current
    if (!el) return
    el.scrollTop = el.scrollHeight
    nearBottomRef.current = true
    setShowJumpToLatest(false)
  }

  async function openConversation(id: string) {
    if (sending) return
    setActiveId(id)
    setLoadingMessages(true)
    // Opening a conversation always lands on the newest message.
    nearBottomRef.current = true
    try {
      const data = await apiFetch<{ conversation: Conversation; messages: ChatMessage[] }>(
        `/api/conversations/${id}`
      )
      setMessages(data.messages)
      setAgent(data.conversation.agentType)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not load conversation')
    } finally {
      setLoadingMessages(false)
    }
  }

  function startNewChat() {
    if (sending) return
    setActiveId(null)
    setMessages([])
    setSavedRecs({})
    nearBottomRef.current = true
    setShowJumpToLatest(false)
  }

  async function handleDeleteConversation(id: string) {
    try {
      await apiFetch(`/api/conversations/${id}`, { method: 'DELETE' })
      if (activeId === id) startNewChat()
      setConversations((prev) => (prev ? prev.filter((c) => c.id !== id) : prev))
      toast.success('Conversation deleted')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not delete conversation')
    }
  }

  async function send() {
    const text = input.trim()
    if (!text || sending) return

    setInput('')
    setSending(true)
    justSentRef.current = true
    const optimisticId = `temp-${Date.now()}`
    setMessages((prev) => [
      ...prev,
      {
        id: optimisticId,
        conversationId: activeId ?? 'new',
        role: 'user',
        content: text,
        agentType: agent,
        meta: null,
        createdAt: new Date().toISOString(),
      },
    ])

    try {
      const data = await apiFetch<{
        conversation: Conversation
        userMessage: ChatMessage
        assistantMessage: ChatMessage
        savedRecommendations: Recommendation[]
      }>('/api/agents/chat', {
        method: 'POST',
        body: JSON.stringify({ conversationId: activeId, agentType: agent, message: text }),
      })

      setMessages((prev) => [
        ...prev.filter((m) => m.id !== optimisticId),
        data.userMessage,
        data.assistantMessage,
      ])
      if (data.savedRecommendations.length > 0) {
        setSavedRecs((prev) => ({
          ...prev,
          [data.assistantMessage.id]: data.savedRecommendations,
        }))
        toast.success(
          `${data.savedRecommendations.length} recommendation${data.savedRecommendations.length > 1 ? 's' : ''} saved to Action Center`
        )
      }
      setActiveId(data.conversation.id)
      setConversations((prev) => {
        const rest = (prev ?? []).filter((c) => c.id !== data.conversation.id)
        return [data.conversation, ...rest]
      })
    } catch (e) {
      setMessages((prev) => prev.filter((m) => m.id !== optimisticId))
      setInput(text)
      toast.error(e instanceof Error ? e.message : 'The team could not respond. Try again.')
    } finally {
      setSending(false)
      textareaRef.current?.focus()
    }
  }

  const activeMeta = useMemo(
    () => conversations?.find((c) => c.id === activeId) ?? null,
    [conversations, activeId]
  )

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      void send()
    }
  }

  return (
    <div className="flex h-[calc(100dvh-9.5rem)] min-h-0 flex-col gap-4 md:h-auto md:min-h-0">
      {/* Header — desktop keeps the full block; mobile gets a compact chat header below */}
      <FadeIn className="hidden md:block">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
          <div>
            <h1 className="text-xl font-semibold tracking-tight md:text-2xl">AI Business Team</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Pick a specialist or let the CEO coordinate. Every agent shares your business memory.
            </p>
          </div>
          <Button variant="secondary" size="sm" onClick={startNewChat} className="shrink-0">
            <MessageSquarePlus className="h-4 w-4" aria-hidden />
            New chat
          </Button>
        </div>
      </FadeIn>

      <div className="grid min-h-0 flex-1 gap-4 overflow-hidden lg:grid-cols-[240px_1fr]">
        {/* Conversations — desktop */}
        <aside className="hidden lg:block">
          <FadeIn>
            <div className="rounded-xl border border-border bg-card/60">
            <div className="border-b border-border/60 px-3 py-2.5">
              <p className="text-xs font-semibold text-muted-foreground">Conversations</p>
            </div>
            <div className="max-h-[480px] overflow-y-auto p-2 scrollbar-slim">
              {conversations === null ? (
                <div className="space-y-2 p-1">
                  {[0, 1, 2].map((i) => (
                    <Skeleton key={i} className="h-12 rounded-lg" />
                  ))}
                </div>
              ) : conversations.length === 0 ? (
                <p className="px-2 py-6 text-center text-xs text-muted-foreground">
                  No conversations yet.
                  <br />
                  Start one on the right.
                </p>
              ) : (
                <ul className="space-y-1">
                  {conversations.map((c) => (
                    <li key={c.id} className="group relative">
                      <button
                        type="button"
                        onClick={() => void openConversation(c.id)}
                        className={cn(
                          'w-full rounded-lg px-2.5 py-2 pr-7 text-left transition-colors',
                          activeId === c.id ? 'bg-primary/10' : 'hover:bg-accent'
                        )}
                      >
                        <span
                          className={cn(
                            'block truncate text-xs font-medium',
                            activeId === c.id ? 'text-primary' : 'text-foreground'
                          )}
                        >
                          {c.title}
                        </span>
                        <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-muted-foreground">
                          <AgentIcon agent={c.agentType} className="h-2.5 w-2.5" />
                          {AGENT_META[c.agentType].name} · {timeAgo(c.updatedAt)}
                        </span>
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete conversation: ${c.title}`}
                        onClick={() => void handleDeleteConversation(c.id)}
                        className="absolute right-1.5 top-2 rounded-md p-1 text-muted-foreground/50 opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          </FadeIn>
        </aside>

        {/* Chat panel */}
        <div className="relative flex min-h-0 min-w-0 flex-col overflow-hidden rounded-xl border border-border bg-card/60">
          {/* Compact chat header: agent selector + controls */}
          <div className="shrink-0 border-b border-border/60 p-2.5 md:p-3">
            <div className="flex items-center gap-2">
              <div className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto pb-0.5 scrollbar-slim">
                {AGENT_ORDER.map((a) => {
                  const meta = AGENT_META[a]
                  const active = agent === a
                  return (
                    <button
                      key={a}
                      type="button"
                      onClick={() => setAgent(a)}
                      aria-pressed={active}
                      className={cn(
                        'relative flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-all active:scale-[0.97]',
                        active
                          ? cn('border-transparent', meta.color)
                          : 'border-border text-muted-foreground hover:border-muted-foreground/40 hover:text-foreground'
                      )}
                    >
                      {/* Sliding active pill — shared layout transition */}
                      {active ? (
                        <motion.span
                          layoutId="team-agent-pill"
                          className={cn('absolute inset-0 rounded-full', meta.bg, meta.border)}
                          transition={springSnappy}
                          aria-hidden
                        />
                      ) : null}
                      <AgentIcon agent={a} className={cn('relative z-10 h-3.5 w-3.5', !active && 'text-muted-foreground')} />
                      <span className="relative z-10">{meta.name}</span>
                    </button>
                  )
                })}
              </div>
              {/* Mobile: compact new-chat control inside the header row */}
              <Button
                variant="ghost"
                size="icon"
                onClick={startNewChat}
                disabled={sending}
                aria-label="New chat"
                className="h-8 w-8 shrink-0 md:hidden"
              >
                <MessageSquarePlus className="h-4 w-4" aria-hidden />
              </Button>
            </div>
            {activeMeta ? (
              <div className="mt-2 lg:hidden">
                <Select
                  value={activeId ?? undefined}
                  onValueChange={(v) => void openConversation(v)}
                >
                  <SelectTrigger className="h-8 text-xs" aria-label="Select conversation">
                    <SelectValue placeholder="Select conversation" />
                  </SelectTrigger>
                  <SelectContent>
                    {(conversations ?? []).map((c) => (
                      <SelectItem key={c.id} value={c.id} className="text-xs">
                        {c.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}
          </div>

          {/* Messages — the panel owns the viewport height on mobile; the list scrolls */}
          <div
            ref={scrollRef}
            onScroll={handleScroll}
            className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-3 scrollbar-slim md:p-4 md:min-h-[380px] md:max-h-[520px]"
          >
            {loadingMessages ? (
              <div className="space-y-4">
                <Skeleton className="ml-auto h-10 w-2/3 rounded-xl" />
                <Skeleton className="h-24 w-4/5 rounded-xl" />
              </div>
            ) : messages.length === 0 ? (
              <FadeIn
                key={agent}
                className="flex h-full flex-col items-center justify-center px-4 py-8 text-center"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-primary/30 bg-primary/10">
                  <Crown className="h-6 w-6 text-primary" aria-hidden />
                </div>
                <p className="mt-4 text-sm font-medium">
                  {activeId ? 'Conversation' : `Talk to ${AGENT_META[agent].name}`}
                </p>
                <p className="mt-1 max-w-sm text-xs leading-relaxed text-muted-foreground">
                  {AGENT_META[agent].blurb} Grounded in your business profile, metrics and history —
                  SELLR never invents numbers.
                </p>
                <Stagger
                  className="mt-5 flex max-w-md flex-wrap justify-center gap-2"
                  stagger={0.04}
                  delay={0.15}
                >
                  {SUGGESTIONS[agent].map((s) => (
                    <StaggerItem key={s}>
                      <button
                        type="button"
                        onClick={() => {
                          setInput(s)
                          textareaRef.current?.focus()
                        }}
                        className="rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground active:scale-[0.97]"
                      >
                        {s}
                      </button>
                    </StaggerItem>
                  ))}
                </Stagger>
              </FadeIn>
            ) : (
              <>
                {messages.map((m) => {
                  if (m.role === 'user') {
                    return (
                      <motion.div
                        key={m.id}
                        className="flex justify-end"
                        initial={{ opacity: 0, y: 14 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.35, ease: EASE_OUT }}
                      >
                        <div className="max-w-[85%] rounded-2xl rounded-br-sm border border-primary/20 bg-primary/10 px-3.5 py-2.5 text-sm leading-relaxed break-words md:px-4">
                          {m.content}
                        </div>
                      </motion.div>
                    )
                  }
                  const meta = parseMeta(m.meta)
                  return (
                    <motion.div
                      key={m.id}
                      className="flex justify-start"
                      initial={{ opacity: 0, y: 14 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.35, ease: EASE_OUT }}
                    >
                      <div className="w-full max-w-[92%] rounded-2xl rounded-bl-sm border border-border bg-secondary/50 px-3.5 py-3 md:px-4">
                        <div className="flex flex-wrap items-center gap-2">
                          <AgentChip agent={m.agentType ?? 'CEO'} />
                          {meta?.confidence ? (
                            <span className="rounded-full border border-border px-1.5 py-0.5 text-[10px] text-muted-foreground">
                              confidence: {meta.confidence.toLowerCase()}
                            </span>
                          ) : null}
                          <span className="ml-auto text-[10px] text-muted-foreground">
                            {timeAgo(m.createdAt)}
                          </span>
                        </div>
                        <div className="agent-markdown mt-2.5 text-sm text-foreground/90">
                          <ReactMarkdown>{m.content}</ReactMarkdown>
                        </div>
                        {(savedRecs[m.id]?.length ?? 0) > 0 ? (
                          <div className="mt-3 space-y-1.5 border-t border-border/60 pt-2.5">
                            {savedRecs[m.id].map((rec) => (
                              <div
                                key={rec.id}
                                className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 px-2.5 py-1.5"
                              >
                                <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-primary" aria-hidden />
                                <p className="text-xs leading-snug">
                                  <span className="font-medium">{rec.title}</span>
                                  <span className="text-muted-foreground">
                                    {' '}
                                    — saved to Action Center ({rec.priority.toLowerCase()} priority)
                                  </span>
                                </p>
                              </div>
                            ))}
                          </div>
                        ) : null}
                        {meta ? <PipelineDisplay meta={meta} /> : null}
                      </div>
                    </motion.div>
                  )
                })}
                {sending ? (
                  <motion.div
                    className="flex justify-start"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, ease: EASE_OUT }}
                  >
                    <div className="w-full max-w-[92%] rounded-2xl rounded-bl-sm border border-border bg-secondary/50">
                      {/* Real request lifecycle: mounted only while the chat
                          fetch is in flight; unmounted on success/error. The
                          agent shown is the one the request actually targets. */}
                      <SellrThinking agent={agent} />
                    </div>
                  </motion.div>
                ) : null}
              </>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Jump to latest — only while the user is reading older messages */}
          {showJumpToLatest && !sending ? (
            <button
              type="button"
              onClick={scrollToLatest}
              className="absolute bottom-24 right-3 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card/90 shadow-lg transition-colors hover:bg-accent md:bottom-20"
              aria-label="Jump to latest message"
            >
              <ArrowDown className="h-4 w-4" aria-hidden />
            </button>
          ) : null}

          {/* Composer — pinned above the keyboard via dvh, respects the bottom safe area */}
          <div className="shrink-0 border-t border-border/60 p-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] md:p-3 md:pb-3">
            <div className="flex items-end gap-2">
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  agent === 'CEO'
                    ? 'Ask your CEO anything about the business…'
                    : `Ask ${AGENT_META[agent].name}…`
                }
                rows={1}
                maxLength={4000}
                disabled={sending}
                className="max-h-40 min-h-11 resize-none bg-secondary/50 text-sm"
                aria-label="Message to your AI team"
              />
              <Button
                size="icon"
                onClick={() => void send()}
                disabled={sending || !input.trim()}
                aria-label="Send message"
                className="h-11 w-11 shrink-0"
              >
                {sending ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <ArrowUp className="h-4 w-4" aria-hidden />
                )}
              </Button>
            </div>
            <p className="mt-1.5 flex items-center gap-1 text-[10px] text-muted-foreground">
              <Bot className="h-3 w-3" aria-hidden />
              Agents recommend — they never execute or fabricate data. Enter to send, Shift+Enter for
              a new line.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
