import { db } from '@/lib/db'
import type { Business } from '@/generated/prisma/client'

/**
 * Shared Business Memory (SELLR.md §4).
 * Every agent call receives this same context — one consistent view of the
 * business, assembled from the user's own profile + recorded metrics +
 * open recommendations/tasks/experiments.
 */

function fmtMoney(n: number): string {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `$${(Math.round(n / 100) / 10).toFixed(1)}k`
  return `$${n.toFixed(0)}`
}

function fmtValue(type: string, v: number): string {
  switch (type) {
    case 'REVENUE':
    case 'AOV':
      return fmtMoney(v)
    case 'CONVERSION':
    case 'CHURN':
      return `${v}%`
    default:
      return String(Math.round(v))
  }
}

const METRIC_LABELS: Record<string, string> = {
  REVENUE: 'Monthly revenue (USD)',
  SALES: 'Sales volume (orders)',
  CUSTOMERS: 'Active customers',
  CONVERSION: 'Conversion rate (%)',
  AOV: 'Average order value (USD)',
  CHURN: 'Churn rate (%)',
}

export async function buildSharedContext(businessId: string): Promise<{
  context: string
  business: Business
}> {
  const business = await db.business.findUnique({
    where: { id: businessId },
    include: {
      metrics: { orderBy: [{ period: 'desc' }, { recordedAt: 'desc' }], take: 120 },
      recommendations: {
        where: { status: { not: 'CANCELLED' } },
        orderBy: { createdAt: 'desc' },
        take: 6,
      },
      tasks: {
        where: { status: { in: ['PLANNED', 'IN_PROGRESS'] } },
        orderBy: { createdAt: 'desc' },
        take: 8,
      },
      experiments: { orderBy: { createdAt: 'desc' }, take: 4 },
    },
  })
  if (!business) throw new Error('Business not found')

  const lines: string[] = []

  // --- Business profile ---
  lines.push('=== SHARED BUSINESS MEMORY (authoritative context — do not contradict) ===')
  lines.push('')
  lines.push('## BUSINESS PROFILE')
  lines.push(`Name: ${business.name}`)
  lines.push(`Type: ${business.businessType}`)
  if (business.platform) lines.push(`Platform: ${business.platform} [USER-REPORTED]`)
  if (business.website) lines.push(`Website: ${business.website}`)
  if (business.description) lines.push(`Description: ${business.description}`)
  if (business.products) lines.push(`Products/Offers: ${business.products}`)
  if (business.targetAudience) lines.push(`Target audience: ${business.targetAudience}`)
  if (business.currentMonthlyRevenue != null)
    lines.push(`Current monthly revenue: ${fmtMoney(business.currentMonthlyRevenue)} [USER-REPORTED]`)
  if (business.monthlyRevenueGoal != null)
    lines.push(`Monthly revenue objective: ${fmtMoney(business.monthlyRevenueGoal)} [USER-REPORTED]`)
  if (business.mainChallenge) lines.push(`Main challenge (owner's words): "${business.mainChallenge}"`)

  // --- Recorded metrics ---
  lines.push('')
  lines.push('## RECORDED BUSINESS METRICS (manual entry by owner)')
  const metricCount = business.metrics.length
  if (metricCount === 0) {
    lines.push('No metrics recorded yet. The user has not connected or entered any business data.')
    lines.push('Do NOT invent numbers. Ask the user to add metrics in Analytics, or answer qualitatively.')
  } else {
    const byType = new Map<string, Map<string, number>>()
    for (const m of business.metrics) {
      if (!byType.has(m.metricType)) byType.set(m.metricType, new Map())
      const periods = byType.get(m.metricType)!
      if (!periods.has(m.period)) periods.set(m.period, m.metricValue)
    }
    for (const [type, periods] of byType) {
      const sorted = [...periods.entries()].sort(([a], [b]) => a.localeCompare(b))
      const last6 = sorted.slice(-6)
      lines.push(
        `${METRIC_LABELS[type] ?? type}: ${last6.map(([p, v]) => `${p}=${fmtValue(type, v)}`).join(', ')}`
      )
    }
    lines.push(`(${metricCount} metric entries total; older entries omitted.)`)
  }

  // --- Open recommendations ---
  lines.push('')
  lines.push('## OPEN RECOMMENDATIONS (AI team output, status-tracked in Action Center)')
  if (business.recommendations.length === 0) {
    lines.push('None yet.')
  } else {
    for (const r of business.recommendations) {
      lines.push(`- [${r.status}] (${r.agentType}, ${r.priority} priority) ${r.title}`)
    }
  }

  // --- Open tasks ---
  lines.push('')
  lines.push('## OPEN TASKS')
  if (business.tasks.length === 0) {
    lines.push('None open.')
  } else {
    for (const t of business.tasks) {
      lines.push(`- [${t.status}] (${t.assignedAgent}, ${t.priority}) ${t.title}`)
    }
  }

  // --- Experiments ---
  if (business.experiments.length > 0) {
    lines.push('')
    lines.push('## EXPERIMENTS')
    for (const e of business.experiments) {
      const base = e.baselineValue != null ? `baseline ${e.baselineValue}` : 'no baseline'
      const target = e.targetValue != null ? `target ${e.targetValue}` : ''
      const result = e.resultValue != null ? `result ${e.resultValue}` : ''
      lines.push(
        `- [${e.status}] "${e.title}" — metric: ${e.metric ?? 'n/a'}, ${base} ${target} ${result}`.trim()
      )
    }
  }

  lines.push('')
  lines.push('=== END OF SHARED BUSINESS MEMORY ===')
  lines.push(
    'REMINDER: Anything not in this memory is unknown. If unknown and it matters, ask the user for it instead of guessing.'
  )

  return { context: lines.join('\n'), business }
}
