import ZAI from 'z-ai-web-dev-sdk'
import type { AgentType, PipelineStep, Priority } from '@/lib/types'
import {
  AGENT_SYSTEM_PROMPTS,
  CEO_SYNTHESIS_TEMPLATE,
  INTENT_CLASSIFIER_SYSTEM,
  SPECIALIST_HANDOFF_TEMPLATE,
} from './prompts'

/**
 * Agent Orchestrator (SELLR.md §9).
 *
 * USER REQUEST → SELLR CEO → INTENT CLASSIFICATION → SPECIALIST AGENT
 *   → ANALYSIS / RECOMMENDATION → CEO VALIDATION → USER RESPONSE
 *
 * All LLM calls are server-side only. Structured JSON is extracted defensively;
 * if the model returns unparseable output we fall back to showing the raw text
 * instead of dropping the turn.
 */

type ChatTurn = { role: 'user' | 'assistant'; content: string }

export interface RecommendationDraft {
  title: string
  description: string
  priority: Priority
  expectedImpact: string | null
}

export interface TurnInput {
  agentType: AgentType
  message: string
  /** Recent conversation history (oldest → newest), excluding the current message. */
  history: ChatTurn[]
  /** Shared business memory (built by context.ts). */
  context: string
}

export interface TurnOutput {
  reply: string
  pipeline: PipelineStep[]
  agentsInvolved: AgentType[]
  confidence: string | null
  recommendations: RecommendationDraft[]
  delegatedTo: AgentType | null
  intent: string | null
}

// ---- ZAI singleton (reuse one instance across requests) ----

type ZAIInstance = Awaited<ReturnType<typeof ZAI.create>>
let zaiInstance: ZAIInstance | null = null

async function getZAI(): Promise<ZAIInstance> {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

// ---- JSON extraction ----

function extractJson(raw: string): Record<string, unknown> | null {
  if (!raw) return null
  let text = raw.trim()
  // Strip markdown fences if the model added them.
  text = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '')
  try {
    const parsed = JSON.parse(text)
    if (parsed && typeof parsed === 'object') return parsed as Record<string, unknown>
  } catch {
    // Fall through: try to locate the outermost JSON object.
  }
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start !== -1 && end > start) {
    try {
      const parsed = JSON.parse(text.slice(start, end + 1))
      if (parsed && typeof parsed === 'object') return parsed as Record<string, unknown>
    } catch {
      return null
    }
  }
  return null
}

// ---- LLM plumbing ----

const MAX_HISTORY_TURNS = 12

async function llmCall(system: string, turns: ChatTurn[]): Promise<string> {
  const zai = await getZAI()
  const trimmedHistory = turns.slice(-MAX_HISTORY_TURNS)
  const completion = await zai.chat.completions.create({
    messages: [
      { role: 'assistant', content: system },
      ...trimmedHistory,
    ],
    thinking: { type: 'disabled' },
  })
  const content = completion.choices[0]?.message?.content ?? ''
  if (!content.trim()) throw new Error('Empty response from model')
  return content
}

interface AgentJsonResult {
  reply: string
  summary: string | null
  findings: string[]
  recommendations: RecommendationDraft[]
  confidence: string | null
  nextActions: string[]
  parseFailed: boolean
}

function normalizeRecommendations(value: unknown): RecommendationDraft[] {
  if (!Array.isArray(value)) return []
  const valid: RecommendationDraft[] = []
  for (const item of value.slice(0, 4)) {
    if (!item || typeof item !== 'object') continue
    const r = item as Record<string, unknown>
    const title = typeof r.title === 'string' ? r.title.trim() : ''
    const description = typeof r.description === 'string' ? r.description.trim() : ''
    if (!title || !description) continue
    const priorityRaw = typeof r.priority === 'string' ? r.priority.toUpperCase() : 'MEDIUM'
    const priority: Priority =
      priorityRaw === 'HIGH' || priorityRaw === 'LOW' ? priorityRaw : 'MEDIUM'
    valid.push({
      title: title.slice(0, 120),
      description: description.slice(0, 1000),
      priority,
      expectedImpact:
        typeof r.expectedImpact === 'string' ? r.expectedImpact.slice(0, 300) : null,
    })
  }
  return valid
}

function parseAgentJson(raw: string): AgentJsonResult {
  const parsed = extractJson(raw)
  if (!parsed || typeof parsed.reply !== 'string' || !parsed.reply.trim()) {
    // Defensive fallback: surface raw text rather than losing the turn.
    return {
      reply: raw.trim().slice(0, 6000) || 'I was unable to generate a response. Please try again.',
      summary: null,
      findings: [],
      recommendations: [],
      confidence: null,
      nextActions: [],
      parseFailed: true,
    }
  }
  const asArray = (v: unknown): string[] =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string').slice(0, 8) : []
  const confidenceRaw = typeof parsed.confidence === 'string' ? parsed.confidence.toUpperCase() : null
  return {
    reply: parsed.reply.trim().slice(0, 8000),
    summary: typeof parsed.summary === 'string' ? parsed.summary.slice(0, 300) : null,
    findings: asArray(parsed.findings),
    recommendations: normalizeRecommendations(parsed.recommendations),
    confidence:
      confidenceRaw === 'HIGH' || confidenceRaw === 'MEDIUM' || confidenceRaw === 'LOW'
        ? confidenceRaw
        : null,
    nextActions: asArray(parsed.nextActions),
    parseFailed: false,
  }
}

function buildUserContent(context: string, message: string, extra?: string): string {
  const parts = [context, '', '=== USER REQUEST ===', message]
  if (extra) parts.push('', extra)
  return parts.join('\n')
}

// ---- Orchestrated turn ----

export async function runAgentTurn(input: TurnInput): Promise<TurnOutput> {
  const { agentType, message, history, context } = input
  const pipeline: PipelineStep[] = []

  // ---- Direct specialist conversation ----
  if (agentType !== 'CEO') {
    const raw = await llmCall(
      AGENT_SYSTEM_PROMPTS[agentType],
      [...history, { role: 'user', content: buildUserContent(context, message) }]
    )
    const result = parseAgentJson(raw)
    pipeline.push({ agent: agentType, action: 'Analyzed your request using shared business memory' })
    return {
      reply: result.reply,
      pipeline,
      agentsInvolved: [agentType],
      confidence: result.confidence,
      recommendations: result.recommendations,
      delegatedTo: null,
      intent: null,
    }
  }

  // ---- CEO flow: classify intent ----
  let intent = 'General guidance'
  let needsSpecialist = false
  let delegateTo: AgentType | null = null

  try {
    const classificationRaw = await llmCall(INTENT_CLASSIFIER_SYSTEM, [
      { role: 'user', content: `Shared business memory:\n${context}\n\nLatest user message: "${message}"` },
    ])
    const classification = extractJson(classificationRaw)
    if (classification) {
      if (typeof classification.intent === 'string' && classification.intent.trim()) {
        intent = classification.intent.trim().slice(0, 60)
      }
      needsSpecialist = classification.needs_specialist === true
      const candidate = typeof classification.delegate_to === 'string' ? classification.delegate_to.toUpperCase() : ''
      if (['ANALYST', 'GROWTH', 'RETENTION', 'OPERATIONS'].includes(candidate)) {
        delegateTo = candidate as AgentType
        needsSpecialist = true
      } else {
        needsSpecialist = false
      }
    }
  } catch {
    // Classification failure → CEO answers directly. Never block the user.
    needsSpecialist = false
  }

  // ---- CEO answers directly ----
  if (!needsSpecialist || !delegateTo) {
    const raw = await llmCall(
      AGENT_SYSTEM_PROMPTS.CEO,
      [...history, { role: 'user', content: buildUserContent(context, message) }]
    )
    const result = parseAgentJson(raw)
    pipeline.push({ agent: 'CEO', action: `Answered directly (intent: ${intent})` })
    return {
      reply: result.reply,
      pipeline,
      agentsInvolved: ['CEO'],
      confidence: result.confidence,
      recommendations: result.recommendations,
      delegatedTo: null,
      intent,
    }
  }

  // ---- Delegation: specialist first ----
  pipeline.push({ agent: 'CEO', action: `Classified intent: ${intent} → delegating to ${delegateTo}` })
  const handoff = SPECIALIST_HANDOFF_TEMPLATE.replace('{intent}', intent).replace('{message}', message)
  const specialistRaw = await llmCall(
    AGENT_SYSTEM_PROMPTS[delegateTo],
    [...history, { role: 'user', content: buildUserContent(context, message, handoff) }]
  )
  const specialistResult = parseAgentJson(specialistRaw)
  pipeline.push({
    agent: delegateTo,
    action: specialistResult.summary
      ? `${delegateTo} analyzed: ${specialistResult.summary}`
      : `${delegateTo} completed the analysis`,
  })

  // ---- CEO validation & synthesis ----
  let reply = specialistResult.reply
  let confidence = specialistResult.confidence
  let recommendations = specialistResult.recommendations
  let synthesisFailed = false

  try {
    const synthesisPrompt = CEO_SYNTHESIS_TEMPLATE.replace('{agent}', delegateTo).replace(
      '{specialistJson}',
      JSON.stringify(
        {
          summary: specialistResult.summary,
          findings: specialistResult.findings,
          recommendations: specialistResult.recommendations,
          confidence: specialistResult.confidence,
          nextActions: specialistResult.nextActions,
        },
        null,
        2
      )
    )
    const ceoRaw = await llmCall(
      AGENT_SYSTEM_PROMPTS.CEO,
      [...history, { role: 'user', content: buildUserContent(context, message, synthesisPrompt) }]
    )
    const ceoResult = parseAgentJson(ceoRaw)
    if (!ceoResult.parseFailed) {
      reply = ceoResult.reply
      confidence = ceoResult.confidence ?? confidence
      // CEO synthesis may adjust the recommendation set; keep its version when non-parse-failed.
      recommendations = ceoResult.recommendations.length > 0 ? ceoResult.recommendations : specialistResult.recommendations
    }
  } catch {
    synthesisFailed = true
    // Keep specialist reply — graceful degradation.
  }

  pipeline.push({ agent: 'CEO', action: synthesisFailed
    ? 'Validated specialist output (synthesis skipped — using specialist response)'
    : 'Validated findings and synthesized the final plan' })

  return {
    reply,
    pipeline,
    agentsInvolved: ['CEO', delegateTo],
    confidence,
    recommendations,
    delegatedTo: delegateTo,
    intent,
  }
}
