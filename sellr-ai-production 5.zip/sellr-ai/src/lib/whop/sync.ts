/**
 * Whop → SELLR data synchronization + normalization (server-side only).
 *
 * METRIC DEFINITIONS (documented, stable — agents and the analytics view rely
 * on these meanings):
 *   REVENUE   = GROSS paid revenue. Sum of Whop payment `total` for payments
 *               with status `paid`, attributed to the month (YYYY-MM, UTC) of
 *               `paid_at` (fallback `created_at`). NOT net of Whop fees; NOT
 *               reduced by refunds. (Whop exposes `amount_after_fees` and
 *               `refunded_amount`; SELLR's BusinessMetric model has no net
 *               revenue slot, so net figures are intentionally not stored.)
 *   SALES     = count of `paid` payments in the period.
 *   CUSTOMERS = count of distinct buyers (user id, else email) with a `paid`
 *               payment in the period.
 *   AOV       = REVENUE / SALES for the period (only written when both are
 *               computable and SALES > 0).
 *   CHURN / CONVERSION are NOT synthesized: cohorts and conversion baselines
 *   cannot be derived honestly from the available endpoints without
 *   assumptions SELLR refuses to make. Missing data is never written as zero.
 *
 * SOURCE PRIORITY POLICY:
 *   The first writer of a (metricType, period) row wins. Whop sync NEVER
 *   overwrites an existing BusinessMetric row of any source — manual entries
 *   are untouchable user truth, and re-running the sync cannot double-count.
 *
 * CURRENCY POLICY:
 *   Amounts are never added across currencies. If the account's paid payments
 *   use more than one currency, only the dominant currency (by gross volume)
 *   is synchronized, and months that also contain other-currency payments are
 *   skipped entirely (a partial month would misstate revenue). Warnings are
 *   recorded in the sync summary and surfaced in the UI.
 */

import { db } from '@/lib/db'
import type { BusinessMetric } from '@/generated/prisma/client'
import {
  fetchAccount,
  fetchAllMemberships,
  fetchAllPayments,
  fetchAllProducts,
  WhopApiError,
  type WhopPayment,
} from './client'
import type { WhopEnvironment } from './config'

export interface SyncSummary {
  synced: number
  skippedExisting: number
  paymentsConsidered: number
  membershipsConsidered: number
  currency: string | null
  warnings: string[]
}

export interface SyncResult {
  ok: boolean
  summary: SyncSummary | null
  error: string | null
  errorKind: 'invalid_key' | 'insufficient_permission' | 'rate_limited' | 'downtime' | 'error' | null
}

/** Period bucket (YYYY-MM) from an ISO timestamp, in UTC. */
function periodOf(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`
}

/** In-process sync lock — prevents two concurrent syncs over the same business. */
const activeSyncs = new Set<string>()

export function isSyncActive(connectionId: string): boolean {
  return activeSyncs.has(connectionId)
}

interface WhopConnectionRow {
  id: string
  businessId: string
  environment: string
  encryptedKey: string
  keyIv: string
  keyTag: string
  whopAccountId: string
}

async function runSync(connection: WhopConnectionRow): Promise<SyncResult> {
  const { openSecret } = await import('./crypto')
  const apiKey = openSecret({
    ciphertext: connection.encryptedKey,
    iv: connection.keyIv,
    tag: connection.keyTag,
  })
  const environment = connection.environment as WhopEnvironment

  // 1. Verify the credential is still valid (throws WhopApiError on 401 etc.)
  const account = await fetchAccount(environment, apiKey)
  if (!account.id) {
    throw new WhopApiError(502, 'error', 'Whop returned an unexpected account response.')
  }
  await db.whopConnection.update({
    where: { id: connection.id },
    data: { lastVerifiedAt: new Date(), whopAccountId: account.id },
  })

  // 2. Pull verified resources (cursor pagination inside the client).
  const [payments, memberships] = await Promise.all([
    fetchAllPayments(environment, apiKey, account.id),
    fetchAllMemberships(environment, apiKey, account.id),
  ])
  // Products are fetched for the summary display (product count) — cheap and
  // gives the UI something real to show; failures here don't block metrics.
  let productCount = 0
  try {
    const products = await fetchAllProducts(environment, apiKey, account.id)
    productCount = products.length
  } catch (e) {
    // Non-fatal: product list is optional context.
    console.warn('[SELLR Whop] product list unavailable during sync', e instanceof Error ? e.message : e)
  }

  // 3. Normalize — only `paid` payments count toward revenue/sales.
  const paid = payments.filter((p) => p.status === 'paid')
  const warnings: string[] = []

  // Currency policy (see module header).
  const byCurrency = new Map<string, WhopPayment[]>()
  for (const p of paid) {
    const list = byCurrency.get(p.currency) ?? []
    list.push(p)
    byCurrency.set(p.currency, list)
  }
  let currency: string | null = null
  let workingSet: WhopPayment[] = []
  if (byCurrency.size === 0) {
    currency = null
  } else if (byCurrency.size === 1) {
    currency = [...byCurrency.keys()][0]
    workingSet = byCurrency.get(currency) ?? []
  } else {
    // Multi-currency: dominant currency by gross volume; other-currency months skipped.
    let bestCurrency = ''
    let bestVolume = -1
    for (const [cur, list] of byCurrency) {
      const volume = list.reduce((sum, p) => sum + p.total, 0)
      if (volume > bestVolume) {
        bestVolume = volume
        bestCurrency = cur
      }
    }
    currency = bestCurrency
    workingSet = byCurrency.get(bestCurrency) ?? []
    const otherCurrencies = [...byCurrency.keys()].filter((c) => c !== bestCurrency)
    warnings.push(
      `Payments exist in multiple currencies (${otherCurrencies.join(', ')}). Only ${bestCurrency} was synchronized; other-currency amounts were never mixed.`
    )
  }

  // Month buckets for the working currency.
  interface MonthBucket {
    revenue: number
    sales: number
    buyers: Set<string>
    mixedWithOtherCurrency: boolean
  }
  const months = new Map<string, MonthBucket>()
  for (const p of workingSet) {
    const period = periodOf(p.paidAt ?? p.createdAt)
    if (!period) continue
    const bucket = months.get(period) ?? { revenue: 0, sales: 0, buyers: new Set<string>(), mixedWithOtherCurrency: false }
    bucket.revenue += p.total
    bucket.sales += 1
    const buyerKey = p.user?.id ?? p.user?.email ?? p.membershipId ?? ''
    if (buyerKey) bucket.buyers.add(buyerKey)
    months.set(period, bucket)
  }
  // In multi-currency mode, refuse months that also contain other-currency payments.
  if (byCurrency.size > 1 && currency) {
    for (const p of paid) {
      if (p.currency === currency) continue
      const period = periodOf(p.paidAt ?? p.createdAt)
      const bucket = months.get(period)
      if (bucket) bucket.mixedWithOtherCurrency = true
    }
    for (const [period, bucket] of months) {
      if (bucket.mixedWithOtherCurrency) {
        months.delete(period)
        warnings.push(`Period ${period} contains mixed currencies and was skipped to avoid misstating revenue.`)
      }
    }
  }

  // 4. Source-priority policy: skip any (metricType, period) that already has a row.
  const periods = [...months.keys()]
  const existing = periods.length
    ? await db.businessMetric.findMany({
        where: { businessId: connection.businessId, period: { in: periods } },
        select: { metricType: true, period: true },
      })
    : []
  const existingKeys = new Set(existing.map((m) => `${m.metricType}:${m.period}`))

  let synced = 0
  let skippedExisting = 0

  function writeMetric(metricType: string, period: string, value: number, now: Date): boolean {
    if (existingKeys.has(`${metricType}:${period}`)) {
      skippedExisting += 1
      return false
    }
    return true
  }

  const rowsToCreate: {
    businessId: string
    metricType: string
    metricValue: number
    period: string
    source: string
    recordedAt: Date
  }[] = []

  for (const [period, bucket] of months) {
    const now = new Date()
    const revenueRounded = Math.round(bucket.revenue * 100) / 100
    if (writeMetric('REVENUE', period, revenueRounded, now)) {
      rowsToCreate.push({
        businessId: connection.businessId,
        metricType: 'REVENUE',
        metricValue: revenueRounded,
        period,
        source: 'WHOP',
        recordedAt: now,
      })
      synced += 1
      existingKeys.add(`REVENUE:${period}`)
    }
    if (writeMetric('SALES', period, bucket.sales, now)) {
      rowsToCreate.push({
        businessId: connection.businessId,
        metricType: 'SALES',
        metricValue: bucket.sales,
        period,
        source: 'WHOP',
        recordedAt: now,
      })
      synced += 1
      existingKeys.add(`SALES:${period}`)
    }
    if (writeMetric('CUSTOMERS', period, bucket.buyers.size, now)) {
      rowsToCreate.push({
        businessId: connection.businessId,
        metricType: 'CUSTOMERS',
        metricValue: bucket.buyers.size,
        period,
        source: 'WHOP',
        recordedAt: now,
      })
      synced += 1
      existingKeys.add(`CUSTOMERS:${period}`)
    }
    if (bucket.sales > 0) {
      const aov = Math.round((bucket.revenue / bucket.sales) * 100) / 100
      if (writeMetric('AOV', period, aov, now)) {
        rowsToCreate.push({
          businessId: connection.businessId,
          metricType: 'AOV',
          metricValue: aov,
          period,
          source: 'WHOP',
          recordedAt: now,
        })
        synced += 1
        existingKeys.add(`AOV:${period}`)
      }
    }
  }

  // 5. Persist. The pre-check above is the first guard against duplicates;
  //    the unique [businessId, metricType, period] constraint is the second.
  //    SQLite has no INSERT OR IGNORE via createMany, so a concurrent-writer
  //    conflict falls back to per-row creates that tolerate duplicates.
  if (rowsToCreate.length > 0) {
    try {
      await db.businessMetric.createMany({ data: rowsToCreate })
    } catch {
      for (const row of rowsToCreate) {
        try {
          await db.businessMetric.create({ data: row })
        } catch {
          // Another writer created this (metricType, period) first — skipped.
        }
      }
    }
  }

  const summary: SyncSummary = {
    synced,
    skippedExisting,
    paymentsConsidered: paid.length,
    membershipsConsidered: memberships.length,
    currency,
    warnings,
  }

  await db.whopConnection.update({
    where: { id: connection.id },
    data: {
      status: 'CONNECTED',
      lastSyncAt: new Date(),
      lastSyncError: null,
      lastSyncSummary: JSON.stringify({ ...summary, productCount }),
    },
  })

  return { ok: true, summary, error: null, errorKind: null }
}

/**
 * Run a synchronization for a stored connection. All failures update the
 * connection status (SYNC_FAILED / REAUTH_REQUIRED) and are returned as a
 * SyncResult — this function never throws.
 */
export async function synchronizeBusiness(connectionId: string): Promise<SyncResult> {
  const connection = await db.whopConnection.findUnique({ where: { id: connectionId } })
  if (!connection) {
    return { ok: false, summary: null, error: 'Whop connection not found.', errorKind: 'error' }
  }
  if (activeSyncs.has(connectionId)) {
    return { ok: false, summary: null, error: 'A synchronization is already running.', errorKind: 'error' }
  }

  activeSyncs.add(connectionId)
  try {
    await db.whopConnection.update({
      where: { id: connectionId },
      data: { status: 'SYNCING' },
    })
    return await runSync({
      id: connection.id,
      businessId: connection.businessId,
      environment: connection.environment,
      encryptedKey: connection.encryptedKey,
      keyIv: connection.keyIv,
      keyTag: connection.keyTag,
      whopAccountId: connection.whopAccountId,
    })
  } catch (e) {
    let message = 'Synchronization failed. Please try again.'
    let kind: SyncResult['errorKind'] = 'error'
    if (e instanceof WhopApiError) {
      message = e.message
      kind = e.kind
    } else if (e instanceof Error) {
      // Surface decryption/config errors loudly; log server-side only.
      console.error('[SELLR Whop] sync failure', connectionId, e.message)
      message = 'Synchronization failed on our side. Please try again.'
    }
    await db.whopConnection.update({
      where: { id: connectionId },
      data: {
        status: kind === 'invalid_key' ? 'REAUTH_REQUIRED' : 'SYNC_FAILED',
        lastSyncError: message,
      },
    }).catch(() => undefined)
    return { ok: false, summary: null, error: message, errorKind: kind }
  } finally {
    activeSyncs.delete(connectionId)
  }
}

/** Count of metrics already stored for a business that came from Whop. */
export async function countWhopMetrics(businessId: string): Promise<number> {
  return db.businessMetric.count({ where: { businessId, source: 'WHOP' } })
}

/** Type helper for status reads (client-safe counterpart lives in types.ts). */
export type SyncedMetric = Pick<BusinessMetric, 'metricType' | 'period' | 'metricValue' | 'source'>
