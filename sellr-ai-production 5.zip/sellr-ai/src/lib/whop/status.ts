/**
 * Builds the client-safe Whop integration status (server-side only).
 * Secrets (API key, webhook secret) are NEVER included — only hints, names
 * and state. Used by the connect / status / sync routes.
 */

import { db } from '@/lib/db'
import { isWhopEncryptionConfigured, isWhopWebhookConfigured } from './config'
import { countWhopMetrics } from './sync'
import type { WhopIntegrationStatus, WhopConnectionPublic, WhopSyncSummary } from '@/lib/types'

function parseSummary(raw: string | null): WhopSyncSummary | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw) as WhopSyncSummary
    return parsed && typeof parsed === 'object' ? parsed : null
  } catch {
    return null
  }
}

export async function buildWhopStatus(businessId: string): Promise<WhopIntegrationStatus> {
  const connection = await db.whopConnection.findUnique({
    where: { businessId },
  })

  if (!connection) {
    return {
      configured: isWhopEncryptionConfigured(),
      webhookConfigured: isWhopWebhookConfigured(),
      connection: null,
    }
  }

  const metricCount = await countWhopMetrics(businessId)

  const payload: WhopConnectionPublic = {
    status: connection.status as WhopConnectionPublic['status'],
    environment: connection.environment === 'production' ? 'production' : 'sandbox',
    whopAccountId: connection.whopAccountId,
    whopAccountName: connection.whopAccountName,
    whopRoute: connection.whopRoute,
    keyHint: connection.keyHint,
    webhookRegistered: Boolean(connection.webhookId && connection.webhookEncryptedSecret),
    lastSyncAt: connection.lastSyncAt?.toISOString() ?? null,
    lastSyncError: connection.lastSyncError,
    lastVerifiedAt: connection.lastVerifiedAt?.toISOString() ?? null,
    summary: parseSummary(connection.lastSyncSummary),
    metricCount,
    connectedAt: connection.createdAt.toISOString(),
  }

  return {
    configured: isWhopEncryptionConfigured(),
    webhookConfigured: isWhopWebhookConfigured(),
    connection: payload,
  }
}
