/**
 * Credential encryption at rest for Whop credentials (server-only by usage).
 *
 * AES-256-GCM via node:crypto. The key comes from the WHOP_ENCRYPTION_KEY
 * environment variable (64 hex chars = 32 bytes) and is never persisted
 * anywhere else, never logged, and never returned through any API response.
 *
 * Wire format (stored in three separate columns):
 *   ciphertext (hex) | iv (hex) | auth tag (hex)
 *
 * If WHOP_ENCRYPTION_KEY is missing or malformed, callers MUST refuse to
 * store credentials rather than silently saving plaintext secrets.
 */

import { createCipheriv, createDecipheriv, createHmac, randomBytes, timingSafeEqual } from 'crypto'
import { WHOP_ENCRYPTION_KEY, isWhopEncryptionConfigured } from './config'

export class WhopCryptoConfigError extends Error {
  constructor() {
    super(
      'Whop credential storage is not configured. Set WHOP_ENCRYPTION_KEY to a 64-character hex string (32 bytes) on the server and restart the app.'
    )
    this.name = 'WhopCryptoConfigError'
  }
}

function getKey(): Buffer {
  if (!isWhopEncryptionConfigured() || !WHOP_ENCRYPTION_KEY) {
    throw new WhopCryptoConfigError()
  }
  const hex = WHOP_ENCRYPTION_KEY.trim().toLowerCase()
  if (!/^[0-9a-f]{64}$/.test(hex)) {
    throw new WhopCryptoConfigError()
  }
  return Buffer.from(hex, 'hex')
}

export interface SealedSecret {
  ciphertext: string
  iv: string
  tag: string
}

/** Encrypt a secret for storage. Throws WhopCryptoConfigError when unset. */
export function sealSecret(plaintext: string): SealedSecret {
  const key = getKey()
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, iv)
  const sealed = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  return {
    ciphertext: sealed.toString('hex'),
    iv: iv.toString('hex'),
    tag: cipher.getAuthTag().toString('hex'),
  }
}

/** Decrypt a stored secret. Throws on tampering (GCM auth failure). */
export function openSecret(sealed: SealedSecret): string {
  const key = getKey()
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(sealed.iv, 'hex'))
  decipher.setAuthTag(Buffer.from(sealed.tag, 'hex'))
  const plain = Buffer.concat([
    decipher.update(Buffer.from(sealed.ciphertext, 'hex')),
    decipher.final(),
  ])
  return plain.toString('utf8')
}

/** Constant-time string comparison (webhook signatures). */
export function safeEqualHex(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8')
  const bufB = Buffer.from(b, 'utf8')
  if (bufA.length !== bufB.length) return false
  return timingSafeEqual(bufA, bufB)
}

/**
 * Compute the Standard Webhooks signature: HMAC-SHA256 over
 * `{webhook-id}.{webhook-timestamp}.{raw body}` with the ws_ secret,
 * base64-encoded — exactly as documented at
 * https://docs.whop.com/developer/guides/webhooks.md
 */
export function standardWebhookSignature(id: string, timestamp: string, rawBody: string, secret: string): string {
  const toSign = `${id}.${timestamp}.${rawBody}`
  return createHmac('sha256', secret).update(toSign, 'utf8').digest('base64')
}
