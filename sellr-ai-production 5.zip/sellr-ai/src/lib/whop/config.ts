/**
 * Whop integration configuration (server-only).
 *
 * Official documentation sources used for this implementation:
 *   - https://docs.whop.com/developer/guides/auth-scoping.md (credential model)
 *   - https://docs.whop.com/developer/quickstart.md (Api-Version-Date pin)
 *   - https://docs.whop.com/developer/guides/webhooks.md (Standard Webhooks)
 *   - https://api.whop.com/api/v1/openapi.json (endpoint shapes)
 *
 * Authorization model (evaluated against the official docs):
 *   OAuth 2.1 + PKCE ("Sign in with Whop") authenticates a USER and requires a
 *   registered OAuth app with an allow-listed redirect URI. It is NOT the
 *   company-data credential. The officially supported way for SELLR's server
 *   to reach a creator's company business data is an ACCOUNT API KEY created
 *   by the business owner (Dashboard → Developer → Account API Keys) and
 *   stored encrypted server-side. This module implements that model.
 *
 * NOTHING in this file may be imported from client components — every export
 * here is server-only by construction: it is imported exclusively from API
 * route handlers, never from React code.
 */

/** Dated API version pin — response shapes never change under it. */
export const WHOP_API_VERSION_DATE = '2026-11-04-1'

export type WhopEnvironment = 'sandbox' | 'production'

/** Sandbox keys come from sandbox.whop.com and hit sandbox-api.whop.com. */
export const WHOP_API_BASES: Record<WhopEnvironment, string> = {
  sandbox: 'https://sandbox-api.whop.com/api/v1',
  production: 'https://api.whop.com/api/v1',
}

export function isWhopEnvironment(value: string): value is WhopEnvironment {
  return value === 'sandbox' || value === 'production'
}

export function whopApiBase(environment: WhopEnvironment): string {
  return WHOP_API_BASES[environment]
}

/**
 * Encryption key for credentials at rest (AES-256-GCM): 64 hex chars = 32
 * bytes. Required for the Whop feature; when missing, connect/sync endpoints
 * return an actionable configuration error instead of storing a plaintext
 * credential.
 */
export const WHOP_ENCRYPTION_KEY = process.env.WHOP_ENCRYPTION_KEY

export function isWhopEncryptionConfigured(): boolean {
  return Boolean(WHOP_ENCRYPTION_KEY && WHOP_ENCRYPTION_KEY.length >= 64)
}

/**
 * Public origin used to register the webhook endpoint with Whop. Whop rejects
 * localhost / private addresses, so this must be the public preview or
 * production URL. Falls back to the request-derived origin when unset.
 */
export const PUBLIC_APP_URL = (
  process.env.PUBLIC_APP_URL ?? process.env.NEXT_PUBLIC_SITE_URL ?? ''
).replace(/\/$/, '')

/**
 * Events this integration subscribes to. Only names verified in the official
 * docs (webhooks guide + API reference) are listed.
 */
export const WHOP_WEBHOOK_EVENTS = [
  'payment.succeeded',
  'payment.failed',
  'membership.activated',
  'membership.updated',
] as const

export function isWhopWebhookConfigured(): boolean {
  return Boolean(PUBLIC_APP_URL)
}
