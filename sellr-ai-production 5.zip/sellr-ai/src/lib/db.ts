import { PrismaPg } from '@prisma/adapter-pg'
import { PrismaClient } from '@/generated/prisma/client'

/**
 * Prisma 7 client over the PrismaPg driver adapter.
 *
 * Connection resolution: POSTGRES_URL first (the sandbox platform exports
 * DATABASE_URL=<sqlite> as a process-level env var, which beats .env files),
 * then DATABASE_URL (the documented Prisma Postgres connection).
 *
 * The client instance is cached on globalThis in non-production so Next.js hot
 * reload does not open a new pool on every file change.
 */
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

function resolveConnectionString(): string {
  const connectionString = process.env.POSTGRES_URL ?? process.env.DATABASE_URL
  if (!connectionString) {
    throw new Error('No POSTGRES_URL / DATABASE_URL set — cannot create the Prisma client.')
  }
  return connectionString
}

function createPrismaClient(): PrismaClient {
  return new PrismaClient({
    adapter: new PrismaPg({ connectionString: resolveConnectionString() }),
  })
}

export const db = globalForPrisma.prisma ?? createPrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
