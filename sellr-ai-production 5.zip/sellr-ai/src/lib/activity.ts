import { db } from '@/lib/db'

export async function logActivity(
  businessId: string,
  type: string,
  description: string,
  agentType?: string | null
) {
  try {
    await db.activity.create({
      data: {
        businessId,
        type,
        description,
        agentType: agentType ?? null,
      },
    })
  } catch (e) {
    // Activity logging must never break the primary operation.
    console.error('[activity] failed to log', e)
  }
}
