import { z } from 'zod'

const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(3, 'Enter your email address')
  .max(200, 'Email is too long')
  .regex(/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, 'Enter a valid email address')

export const registerSchema = z.object({
  fullName: z.string().trim().min(2, 'Enter your full name').max(80, 'Name is too long'),
  email: emailSchema,
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(128, 'Password is too long'),
})

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Enter your password').max(128),
})

export const forgotPasswordSchema = z.object({
  email: emailSchema,
})

export const resetPasswordSchema = z.object({
  // Local provider: single-use hashed token delivered via reset link.
  token: z.string().min(20).max(200).optional(),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(128, 'Password is too long'),
})

export const resendVerificationSchema = z.object({
  email: emailSchema,
})

const nullableNumber = z.coerce.number().min(0).max(1_000_000_000).nullable()

export const businessSchema = z.object({
  name: z.string().trim().min(2, 'Business name is required').max(100),
  businessType: z.string().trim().min(2, 'Business type is required').max(60),
  platform: z.string().trim().max(80).nullable().optional(),
  website: z.string().trim().max(200).nullable().optional(),
  description: z.string().trim().max(600).nullable().optional(),
  products: z.string().trim().max(500).nullable().optional(),
  targetAudience: z.string().trim().max(300).nullable().optional(),
  currentMonthlyRevenue: nullableNumber,
  monthlyRevenueGoal: nullableNumber,
  mainChallenge: z.string().trim().max(300).nullable().optional(),
  onboarded: z.boolean().optional(),
})

export const METRIC_TYPES = ['REVENUE', 'SALES', 'CUSTOMERS', 'CONVERSION', 'AOV', 'CHURN'] as const

export const metricSchema = z.object({
  metricType: z.enum(METRIC_TYPES),
  metricValue: z.coerce.number().min(0, 'Value must be zero or greater'),
  period: z
    .string()
    .regex(/^\d{4}-(0[1-9]|1[0-2])$/, 'Period must be in YYYY-MM format'),
})

export const AGENT_TYPES = ['CEO', 'ANALYST', 'GROWTH', 'RETENTION', 'OPERATIONS'] as const

export const chatSchema = z.object({
  conversationId: z.string().uuid().nullable().optional(),
  agentType: z.enum(AGENT_TYPES).default('CEO'),
  message: z
    .string()
    .trim()
    .min(1, 'Type a message first')
    .max(4000, 'Message is too long (max 4000 characters)'),
})

export const PRIORITIES = ['HIGH', 'MEDIUM', 'LOW'] as const

export const recommendationStatusSchema = z.object({
  status: z.enum(['SUGGESTED', 'PLANNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']),
})

export const taskCreateSchema = z.object({
  title: z.string().trim().min(2, 'Task title is required').max(160),
  description: z.string().trim().max(1000).nullable().optional(),
  assignedAgent: z.enum(AGENT_TYPES).default('OPERATIONS'),
  priority: z.enum(PRIORITIES).default('MEDIUM'),
  dueDate: z.string().datetime().nullable().optional(),
  recommendationId: z.string().uuid().nullable().optional(),
})

export const taskUpdateSchema = z.object({
  status: z.enum(['PLANNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']).optional(),
  priority: z.enum(PRIORITIES).optional(),
  title: z.string().trim().min(2).max(160).optional(),
  description: z.string().trim().max(1000).nullable().optional(),
  dueDate: z.string().datetime().nullable().optional(),
})

export const experimentCreateSchema = z.object({
  title: z.string().trim().min(2, 'Experiment title is required').max(160),
  hypothesis: z.string().trim().max(600).nullable().optional(),
  metric: z.string().trim().max(80).nullable().optional(),
  baselineValue: z.coerce.number().nullable().optional(),
  targetValue: z.coerce.number().nullable().optional(),
})

export const experimentUpdateSchema = z.object({
  status: z.enum(['PLANNED', 'RUNNING', 'COMPLETED', 'CANCELLED']).optional(),
  resultValue: z.coerce.number().nullable().optional(),
})

// ---- Whop integration ----

export const whopConnectSchema = z.object({
  // Whop Account API key (created by the business owner in their dashboard).
  // Accepted here only for the one-time server-side verification + encrypted
  // storage; it is never persisted unencrypted and never echoed back.
  apiKey: z
    .string()
    .trim()
    .min(10, 'That does not look like a Whop API key')
    .max(250, 'API key is too long'),
  environment: z.enum(['sandbox', 'production']),
})

export type WhopConnectInput = z.infer<typeof whopConnectSchema>

export type RegisterInput = z.infer<typeof registerSchema>
export type BusinessInput = z.infer<typeof businessSchema>
export type MetricInput = z.infer<typeof metricSchema>
export type ChatInput = z.infer<typeof chatSchema>
