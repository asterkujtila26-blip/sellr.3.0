'use client'

import { create } from 'zustand'
import { apiFetch } from '@/lib/client-api'
import type { AuthProvider, Business, SessionUser } from '@/lib/types'

export type View =
  | 'landing'
  | 'auth'
  | 'forgot'
  | 'reset'
  | 'verify'
  | 'onboarding'
  | 'dashboard'
  | 'team'
  | 'actions'
  | 'analytics'
  | 'business'

export interface ForgotPasswordResult {
  ok: boolean
  resetUrl?: string
}

/**
 * Shown when a fresh register/login succeeded but /api/auth/me afterwards
 * returns no session — i.e. the browser did not keep the session cookie
 * (blocked/third-party cookie settings). Must be a VISIBLE error, never a
 * silent bounce back to the landing page.
 */
export const SESSION_COOKIE_ERROR =
  "Your session couldn't be saved — enable cookies or open the app in a new tab."

interface SellrState {
  booted: boolean
  view: View
  user: SessionUser | null
  business: Business | null
  authMode: 'login' | 'register'
  provider: AuthProvider
  /** Set when sign-up returns "verify your email" (Supabase). */
  pendingVerificationEmail: string | null
  /** Surfaced from /auth/callback when an email action fails. */
  authNotice: { kind: 'error' | 'info'; message: string } | null
  /** Visible error when a fresh session cookie failed to persist. */
  sessionError: string | null
  /** Raw token from a local-provider reset link (?reset=...). */
  resetToken: string | null
  /** True while the current view was established by a URL param (email action links). */
  urlDriven: boolean
  bootstrap: (opts?: { afterAuth?: boolean }) => Promise<void>
  setView: (v: View) => void
  setAuthMode: (m: 'login' | 'register') => void
  setUser: (u: SessionUser | null) => void
  setBusiness: (b: Business | null) => void
  setAuthNotice: (n: SellrState['authNotice']) => void
  setSessionError: (message: string | null) => void
  requestPasswordReset: (email: string) => Promise<ForgotPasswordResult>
  completePasswordReset: (password: string) => Promise<void>
  resendVerification: () => Promise<void>
  logout: () => Promise<void>
}

export const useSellr = create<SellrState>((set, get) => ({
  booted: false,
  view: 'landing',
  user: null,
  business: null,
  authMode: 'register',
  provider: 'local',
  pendingVerificationEmail: null,
  authNotice: null,
  sessionError: null,
  resetToken: null,
  urlDriven: false,

  bootstrap: async (opts) => {
    const afterAuth = opts?.afterAuth === true
    try {
      const data = await apiFetch<{
        user: SessionUser | null
        business: Business | null
        provider?: AuthProvider
      }>('/api/auth/me')

      const provider: AuthProvider = data.provider ?? 'local'
      const { view: currentView, urlDriven } = get()

      /**
       * A URL param (reset link / email action callback) owns the current
       * view until the user navigates. Bootstrap must not clobber it.
       */
      const decide = (fallback: View): View => {
        if (
          urlDriven &&
          (currentView === 'reset' ||
            currentView === 'forgot' ||
            currentView === 'verify' ||
            currentView === 'auth')
        ) {
          return currentView
        }
        return fallback
      }

      if (!data.user) {
        if (afterAuth) {
          // Register/login JUST succeeded but /api/auth/me has no session —
          // the cookie did not survive (blocked/third-party cookies). Surface
          // a visible error and stay on the auth screen. NEVER silently
          // bounce the user back to the landing page.
          set({
            booted: true,
            user: null,
            business: null,
            provider,
            urlDriven: false,
            view: 'auth',
            sessionError: SESSION_COOKIE_ERROR,
          })
          return
        }
        set({
          booted: true,
          user: null,
          business: null,
          provider,
          urlDriven: false,
          view: decide('landing'),
        })
        return
      }
      if (!data.business || !data.business.onboarded) {
        set({
          booted: true,
          user: data.user,
          business: data.business,
          provider,
          urlDriven: false,
          sessionError: null,
          view: decide('onboarding'),
        })
        return
      }
      set({
        booted: true,
        user: data.user,
        business: data.business,
        provider,
        urlDriven: false,
        sessionError: null,
        view:
          decide(
            currentView === 'landing' ||
              currentView === 'auth' ||
              currentView === 'forgot' ||
              currentView === 'verify' ||
              currentView === 'onboarding'
              ? 'dashboard'
              : currentView
          ),
      })
    } catch {
      const { view: currentView, urlDriven } = get()
      if (afterAuth) {
        // Same as above: a fresh sign-in must fail LOUDLY, not send the user
        // back to the landing page as if the account does not exist.
        set({
          booted: true,
          user: null,
          business: null,
          view: 'auth',
          sessionError: SESSION_COOKIE_ERROR,
        })
        return
      }
      set({
        booted: true,
        user: null,
        business: null,
        view:
          urlDriven && (currentView === 'reset' || currentView === 'forgot')
            ? currentView
            : 'landing',
      })
    }
  },

  setView: (v) => set({ view: v }),
  setAuthMode: (m) => set({ authMode: m, pendingVerificationEmail: null }),
  setUser: (u) => set({ user: u }),
  setBusiness: (b) => set({ business: b }),
  setAuthNotice: (n) => set({ authNotice: n }),
  setSessionError: (message) => set({ sessionError: message }),

  requestPasswordReset: async (email: string) => {
    const data = await apiFetch<ForgotPasswordResult>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    })
    return data
  },

  completePasswordReset: async (password: string) => {
    const token = get().resetToken
    await apiFetch('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(token ? { token, password } : { password }),
    })
    set({ resetToken: null })
  },

  resendVerification: async () => {
    const email = get().pendingVerificationEmail
    if (!email) return
    await apiFetch('/api/auth/resend-verification', {
      method: 'POST',
      body: JSON.stringify({ email }),
    })
  },

  logout: async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' })
    } finally {
      set({
        user: null,
        business: null,
        view: 'landing',
        pendingVerificationEmail: null,
        resetToken: null,
      })
    }
  },
}))
