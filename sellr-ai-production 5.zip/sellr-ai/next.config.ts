import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* Prisma 7 runs on the pg driver adapter — keep pg unbundled server-side. */
  serverExternalPackages: ["pg", "@prisma/adapter-pg"],
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
