import "dotenv/config";
import { defineConfig, env } from "prisma/config";

/**
 * Prisma 7 configuration (https://www.prisma.io/docs/orm/prisma-config).
 * The CLI (migrate / generate / db push) reads the datasource URL from here;
 * the runtime client reads DATABASE_URL itself via the PrismaPg adapter
 * (see src/lib/db.ts).
 *
 * POSTGRES_URL first: the sandbox platform exports DATABASE_URL=<sqlite> as a
 * process-level env var (which beats .env files in every loader), so the real
 * Prisma Postgres connection travels in POSTGRES_URL. DATABASE_URL remains the
 * documented fallback.
 */
export default defineConfig({
  schema: "prisma/schema.prisma",
  migrations: {
    path: "prisma/migrations",
  },
  datasource: {
    url: process.env.POSTGRES_URL ?? env("DATABASE_URL"),
  },
});
